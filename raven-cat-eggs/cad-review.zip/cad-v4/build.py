"""Print-in-place candidate from approved v3 meshes; mm. Run on CAD farm."""
from pathlib import Path
import json, math
import numpy as np
import trimesh as tm
import manifold3d as md
P=Path(__file__).resolve().parent
RI=7.0; HOLE=7.6; SHOULDER=10.2; CONE_START=1.8; LIFT=4.8

def solid(m):
 return md.Manifold(md.Mesh(vert_properties=np.asarray(m.vertices,dtype=np.float32),tri_verts=np.asarray(m.faces,dtype=np.uint32)))
def mesh(s):
 s=s.simplify(.0001);m=s.to_mesh();r=tm.Trimesh(vertices=m.vert_properties[:,:3],faces=m.tri_verts,process=True,validate=True)
 
 if not r.is_watertight:
  counts=np.bincount(r.edges_unique_inverse);bad=r.edges_unique[counts!=2];print('BAD EDGES',len(bad),r.vertices[bad[:12]].tolist(), 'COUNTS',counts[counts!=2].tolist(),flush=True)
 assert r.is_volume, f'Invalid exported volume: status={s.status()} watertight={r.is_watertight}, winding={r.is_winding_consistent}, volume={r.volume}'
 return r

def load(n):return solid(tm.load_mesh(P/'input'/(n+'.stl'),process=True))
def cyl(r,z0,z1):return md.Manifold.cylinder(z1-z0,r,r,128).translate((0,0,z0))
def export(n,s,color,kind):
 m=mesh(s);m.export(P/(n+'.stl'))
 # Read back float32 STL; preview is exactly the printable triangle set.
 m=tm.load_mesh(P/(n+'.stl'),process=True);assert m.is_volume
 (P/(n+'.json')).write_text(json.dumps(dict(name=n,positions=m.vertices.ravel().tolist(),indices=m.faces.ravel().tolist()),separators=(',',':')))
 manifest['parts'].append(dict(name=n,color=color,triangles=len(m.faces)))
 manifest['placements'].append(dict(name=n,kind=kind,assembly_z=0))
 print(n,len(m.faces),m.volume,flush=True)
 return m

manifest=json.loads((P/'input/manifest.json').read_text())
manifest.update(version=4,animal_height_mm=36.8,body_lift_mm=LIFT,foot_radius_mm=RI,bottom_hole_radius_mm=HOLE,shoulder_radius_mm=SHOULDER,cone_start_mm=CONE_START,parts=[],placements=[],print_in_place=True,no_insertion_pause=True,review_only=True)
for key in ('pause_candidate_mm',):manifest.pop(key,None)
shell=load('egg_blue')-cyl(HOLE,-1,1.3)
export('egg_blue',shell,'blue','shell')
foot=cyl(RI,0,CONE_START+.02)+md.Manifold.cylinder(3.2,RI,SHOULDER,128).translate((0,0,CONE_START))
for kind in ('raven','cat'):
 body=load(kind+'_pink')
 # Socket dimensions came from the v1 eye bounding boxes, minus original .6 mm seat.
 old=tm.load_mesh(P/'input'/(kind+'_blue_eyes.stl'),process=True)
 eyes=[]
 for side in (-1,1):
  v=old.vertices[old.vertices[:,0]*side>0];lo=v.min(axis=0);hi=v.max(axis=0);c=(lo+hi)/2;c[2]-=.6
  size=(hi-lo)/2+.30
  eye=md.Manifold.sphere(1,96).scale(tuple(size)).translate(tuple(c))
  eyes.append(eye)
 blue=eyes[0]+eyes[1]
 # Filling the old fit allowance makes these bonded color regions, not loose inserts.
 whole=body+blue
 pink=(body-blue).translate((0,0,LIFT))+foot
 blue=blue.translate((0,0,LIFT))
 print('PINK components',kind,[q.volume() for q in pink.decompose()],flush=True)
 if kind=='raven':
  # A permanent 45-degree-or-steeper underside joins the hooked beak to the chest.
  # This replaces the floating first beak layer, without trapped removable supports.
  points=[]
  for z,y,rx,ry in [(16.0,-5.0,2.0,1.8),(24.55,-13.2,1.15,1.35)]:
   for a in np.linspace(0,2*np.pi,64,endpoint=False):points.append([rx*np.cos(a),y+ry*np.sin(a),z])
  ramp=md.Manifold.hull_points(np.array(points))
  pink=pink+ramp
  manifest['beak_underside']='Continuous tapered ramp from chest to hooked beak; no separate support.'
 if kind=='cat':
  # Extend abrupt ear undersides down into the head with tapered, attached roots.
  original=tm.load_mesh(P/'input/cat_pink.stl',process=True).vertices.copy();original[:,2]+=LIFT
  for side in (-1,1):
   ear=original[(original[:,0]*side>6)&(original[:,2]>=32.35)&(original[:,2]<=33.0)]
   roots=np.array([[side*5.2+1.8*np.cos(a),2.5*np.sin(a),29.5] for a in np.linspace(0,2*np.pi,64,endpoint=False)])
   pink=pink+md.Manifold.hull_points(np.vstack([ear,roots]))
  manifest['ear_undersides']='Tapered ear roots into the head; no separate support.'


 export(kind+'_pink',pink,'pink',kind)
 export(kind+'_blue_eyes',blue,'blue',kind)
manifest['previews']={'hatched':'egg_nest_preview','meaning':'Exact lower shell cut at the groove; physical fracture and release untested.'}
(P/'manifest.json').write_text(json.dumps(manifest,indent=2))
print('V4 complete; unprinted candidate',flush=True)
