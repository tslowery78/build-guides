import subprocess,sys
for s in ('build.py','nest_preview.py','check.py','check_layers.py'):
 subprocess.run([sys.executable,s],check=True)
