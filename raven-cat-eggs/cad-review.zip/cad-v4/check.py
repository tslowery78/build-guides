"""v4 checks for enclosed print-in-place; replaces v3 insertion/eye-fit checks."""
import json, numpy as np,trimesh as tm, manifold3d as md
from pathlib import Path
P=Path(__file__).resolve().parent
M=json.loads((P/'manifest.json').read_text());checks=[]
def check(name,cond,**detail):
 checks.append(dict(name=name,pass_=bool(cond),**detail));print(name,bool(cond),detail,flush=True)
def sol(m):return md.Manifold(md.Mesh(vert_properties=np.asarray(m.vertices,dtype=np.float32),tri_verts=np.asarray(m.faces,dtype=np.uint32)))
def mesh(n):return tm.load_mesh(P/(n+'.stl'),process=True)
parts={p['name']:mesh(p['name']) for p in M['parts']}
for name,m in parts.items():
 check(name+' valid closed volume',m.is_volume,volume_mm3=float(m.volume))
 j=json.loads((P/(name+'.json')).read_text());q=tm.Trimesh(np.array(j['positions']).reshape(-1,3),np.array(j['indices']).reshape(-1,3),process=True)
 check(name+' exact printable preview',np.array_equal(m.triangles,q.triangles))
shell=parts['egg_blue'];S=sol(shell);pairs={'pink':[],'blue':[]}
for kind,x in [('raven',-26),('cat',26)]:
 pink=parts[kind+'_pink'];blue=parts[kind+'_blue_eyes'];A=sol(pink)+sol(blue)
 vols=[q.volume() for q in A.decompose()]
 # Float32 Boolean reunion can create zero-volume numerical sheets; tolerance is 1e-7 mm3.
 check(kind+' one bonded animal volume',sum(v>1e-7 for v in vols)==1 and sum(abs(v) for v in vols if v<=1e-7)<1e-7,component_volumes_mm3=vols)
 overlap=(sol(pink)^sol(blue)).volume();check(kind+' color regions disjoint',abs(overlap)<1e-5,overlap_mm3=overlap)
 overlap=(A^S).volume();check(kind+' animal separated from shell',abs(overlap)<1e-5,overlap_mm3=overlap)
 check(kind+' bed contact',abs(pink.bounds[0,2])<1e-5)
 # Radial base clearance includes faceted circle chord error.
 check(kind+' floor radial clearance',7.6*np.cos(np.pi/128)-7>.5,minimum_mm=float(7.6*np.cos(np.pi/128)-7))
 # At r=hole, cone underside z=1.8+(r-7); floor at1.2.
 check(kind+' shoulder floor gap',1.8+(7.6-7)-1.2>.9,gap_mm=1.8+(7.6-7)-1.2)
 check(kind+' captured shoulder',10.2>7.6,radial_overlap_mm=10.2-7.6)
 # Verify no shell hit during full vertical extraction after removing top.
 nestj=json.loads((P/'egg_nest_preview.json').read_text());nest=tm.Trimesh(np.array(nestj['positions']).reshape(-1,3),np.array(nestj['indices']).reshape(-1,3),process=True);N=sol(nest)
 vs=[(A.translate((0,0,float(z)))^N).volume() for z in np.arange(0,24,.5)]
 check(kind+' clears nest on vertical removal',max(vs)<1e-5,max_overlap_mm3=max(vs))
 for m,col in [(pink,'pink'),(blue,'blue'),(shell,'blue')]:
  q=m.copy();q.apply_translation([x,0,0]);pairs[col].append(q)
 # Body shell distance by nearest surface vertices (diagnostic, sampled not a proof).
 points=np.concatenate([pink.vertices[::10],blue.vertices[::10]])
 dist=np.concatenate([shell.nearest.on_surface(points[i:i+32])[1] for i in range(0,len(points),32)])
 check(kind+' sampled separation at least .5 mm',dist.min()>.5,sampled_min_mm=float(dist.min()))
for col,items in pairs.items():tm.util.concatenate(items).export(P/('pair_'+col+'.stl'))
check('two egg spacing',52-shell.extents[0]>7,gap_mm=float(52-shell.extents[0]))
check('one print/no loading pause',M['print_in_place'] and M['no_insertion_pause'])
(P/'checks.json').write_text(json.dumps(dict(checks=checks,passed=all(c['pass_'] for c in checks),limitations=['Physical shell opening and animal release untested.','Slicer overhang paths need review before print.']),indent=2))
assert all(c['pass_'] for c in checks)
