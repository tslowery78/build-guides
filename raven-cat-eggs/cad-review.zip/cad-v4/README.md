# Raven and cat eggs — v4 print-in-place candidate

Both animals and both shells are produced together on one plate, using pink and blue PLA. Blue eyes are bonded color regions, not fitted inserts. No assembly or insertion pause.

Each animal starts on a 14 mm diameter foot on the build plate. The shell floor has a 15.2 mm hole. A 45 degree tapered shoulder expands to 20.4 mm above the floor and retains the animal when lifted. The foot can settle about 1.2 mm below the egg bottom; this is not a sealed-bottom egg. The shell opens at the original irregular groove; the animal then lifts through the open nest.

The raven beak has a tapered underside joined to its chest so its downward tip does not start in mid-air. This is a visible functional change from v3 and is included in the spinning preview. No internal removable support is intended.

Unprinted: CAD clearance and slice checks cannot establish real release force, fracture behavior, surface quality or child opening effort. The first paired run is a prototype; an adult should check opening and edges before the children use it.

Rebuild on a helper with numpy, trimesh, manifold3d, scipy, shapely, networkx and rtree: build.py, nest_preview.py, check.py, check_layers.py. Sources in input preserve the v3 animal/shell STL and v1 eye-coordinate references. Preview JSON uses exact exported STL triangles. Numerical Boolean simplification tolerance 0.0001 mm; failed topology checks stop export.
