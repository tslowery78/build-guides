"""Derive a watertight illustration of the lower shell from the exact printable STL.
This cut is along the designed weak path, not a fracture simulation.
"""
import json,math
from pathlib import Path
import numpy as np,trimesh,manifold3d
P=Path(__file__).resolve().parent
manifest=json.loads((P/'manifest.json').read_text())
knots=np.array(manifest['crack_knots_degrees_mm']);N=240
aa=np.arange(N)*2*math.pi/N
raw=lambda a:np.interp(np.degrees(a)%360,knots[:,0],knots[:,1])
h=(raw(aa-math.pi/180)+2*raw(aa)+raw(aa+math.pi/180))/4
d=1.06*23.2*(-(h-23)/(1024*np.sqrt(1-((h-23)/32)**2))*(1-.25*h/55)-np.sqrt(1-((h-23)/32)**2)*.25/55)
# Offset the visual cut by 0.005 mm to avoid Boolean coincidence with groove vertices.
# This lies inside the weak band; it is not a predicted physical fracture offset.
h=h+.5*d/np.sqrt(1+d*d)+.005
v=[[0,0,20]]
for r,z in ((10,h),(40,h),(40,np.full(N,-1))):
 v.extend(np.column_stack((r*np.cos(aa),r*np.sin(aa),z)).tolist())
b=len(v);v.append([0,0,-1]);faces=[]
for j in range(N):
 k=(j+1)%N
 faces.extend([(0,1+j,1+k),(1+j,1+N+j,1+N+k),(1+j,1+N+k,1+k),
 (1+N+j,1+2*N+j,1+2*N+k),(1+N+j,1+2*N+k,1+N+k),(b,1+2*N+k,1+2*N+j)])
cutter=trimesh.Trimesh(vertices=v,faces=faces,process=True)
cutter.fix_normals()
assert cutter.is_volume
shell=trimesh.load_mesh(P/'egg_blue.stl',process=True)
nest=trimesh.boolean.intersection([shell,cutter],engine='manifold')
# Collapse Boolean slivers smaller than 0.0001 mm before browser vertex welding.
# Manifold guarantees surfaces move by less than this tolerance.
solid=manifold3d.Manifold(manifold3d.Mesh(vert_properties=np.asarray(nest.vertices,dtype=np.float32),tri_verts=np.asarray(nest.faces,dtype=np.uint32))).simplify(.0001)
clean=solid.to_mesh()
nest=trimesh.Trimesh(vertices=clean.vert_properties[:,:3],faces=clean.tri_verts,process=False)
# Validate again after the float32 conversion used by the browser.
nest=trimesh.Trimesh(vertices=np.asarray(nest.vertices,dtype=np.float32),faces=nest.faces,process=True)
assert nest.is_volume
(P/'egg_nest_preview.json').write_text(json.dumps({'name':'egg_nest_preview','positions':np.asarray(nest.vertices,dtype=np.float32).ravel().tolist(),'indices':nest.faces.ravel().tolist()},separators=(',',':')))
print('Derived nest:',len(nest.faces),'triangles, volume',nest.volume,'mm3; watertight:',nest.is_watertight)
