"""V3 original CAD. Blender on mini. Units mm; appearance/fit review, not print release."""
import bpy,bmesh,json,math,struct,shutil
from pathlib import Path
from mathutils import Vector
P=Path(__file__).resolve().parent
# Reuse our original geometry helpers, without executing the v1 scene build.
src=(P.parent/'cad-v1/build.py').read_text()
start=src.index(" # Blue eye inlays"); end=src.index("\ndef radius",start)
src=src[:start]+" return [o]\n"+src[end:]
exec(src[:src.index("parts=animal('raven')")])
OUT=P
original_radius=radius
def radius(z): return 1.06*original_radius(z)
H=55.; FLOOR=1.2; SEAT=1.2; PAUSE=39.; WALL=1.4; WEAK=.9; SEAM=20.
# Preserve the approved animal/eye meshes exactly instead of remeshing the sculpt.
previous=json.loads((P.parent/'cad-v2/manifest.json').read_text())
parts=[];placements=[p for p in previous['placements'] if p['kind']!='shell']
def copy(o,name):
 q=o.copy();q.data=o.data.copy();bpy.context.collection.objects.link(q);q.name=name;return q
for part in previous['parts']:
 if part['name']=='egg_blue':continue
 bpy.ops.wm.stl_import(filepath=str(P.parent/'cad-v2'/(part['name']+'.stl')))
 o=bpy.context.object;o.name=part['name'];parts.append(o)

# Smooth ovoid with inner surface offset in the meridian normal direction.
def dr(z):
 t=max(1e-8,1-((z-23)/32)**2)
 return 1.06*23.2*(-(z-23)/(1024*math.sqrt(t))*(1-.25*z/H)-math.sqrt(t)*.25/H)
def inner(z):
 d=dr(z);n=math.sqrt(1+d*d)
 return radius(z)-WALL/n,z+WALL*d/n

# Uneven spacing and heights make a continuous fracture-like path, not a regular sawtooth.
CRACK_KNOTS=[(0,20.4),(17,22.1),(31,20.5),(49,21.2),(63,18.3),(82,19.1),
 (99,17.9),(121,21.6),(138,20.3),(157,22.7),(173,21.4),(191,19.0),
 (216,20.1),(231,17.8),(247,19.3),(261,20.7),(279,18.1),(298,19.1),
 (313,22.3),(333,20.6),(349,21.0),(360,20.4)]
def raw_crack(a):
 deg=math.degrees(a)%360
 for (a0,z0),(a1,z1) in zip(CRACK_KNOTS[:-1],CRACK_KNOTS[1:]):
  if a0<=deg<=a1:return z0+(z1-z0)*(deg-a0)/(a1-a0)
 raise ValueError(deg)
def crack(a):
 # Round only the corner tips over about 0.8 mm of circumference.
 d=math.radians(1)
 return (raw_crack(a-d)+2*raw_crack(a)+raw_crack(a+d))/4
GROOVE_HALF_WIDTH=.6
# Align shell rings with the groove center and shoulders at every angle.
def warped_z(z,a):
 w=max(0,min(1,(z-9)/9.8,(31-z)/9.8))
 return z+(crack(a)-SEAM)*w
def groove(z,a):
 return (WALL-WEAK)*max(0,1-abs(z-crack(a))/GROOVE_HALF_WIDTH)
def thumb(z,a):
 da=math.atan2(math.sin(a+math.pi/2),math.cos(a+math.pi/2))
 return .5*max(0,1-(da/.24)**2)*max(0,1-((z-crack(a)-2.1)/2.1)**2)
def cut_height(a):
 z=crack(a);d=dr(z)
 return z+(WALL-WEAK)*d/math.sqrt(1+d*d)
n=240;zs=sorted(set([i*H/220 for i in range(221)]+[18.8,19.4,20,20.6,21.2,22.1,24.2,39]))
# Closed meridian has two axis segments; normals must orient cavity inward.
v=[];rings=[]
def ring(r,z):
 if abs(r)<1e-7: rings.append([len(v)]);v.append((0,0,z))
 else:
  ids=[]
  for j in range(n):
   a=j*2*math.pi/n;ids.append(len(v));v.append((r*math.cos(a),r*math.sin(a),z))
  rings.append(ids)
ring(0,0)
for z in zs[:-1]:
 ids=[]
 for j in range(n):
  a=j*2*math.pi/n;wz=warped_z(z,a);d=dr(wz);norm=math.sqrt(1+d*d)
  cut=max(groove(wz,a),thumb(wz,a));r=radius(wz)-cut/norm;zz=wz+cut*d/norm
  ids.append(len(v));v.append((r*math.cos(a),r*math.sin(a),zz))
 rings.append(ids)
ring(0,H);outer_count=n*(len(zs))
ring(0,H-WALL)
# Stop inner offset at the horizontal floor, interpolate exact intersection.
inner_points=[inner(z) for z in zs[:-1]]
for i,(r,z) in enumerate(inner_points):
 if z>=FLOOR:
  ra,za=inner_points[i-1];rf=ra+(r-ra)*(FLOOR-za)/(z-za);inner_points= [(rf,FLOOR)]+inner_points[i:];break
for r,z in reversed(inner_points):ring(r,z)
ring(0,FLOOR)
f=[]
for a,b in zip(rings[:-1],rings[1:]):
 if len(a)==1 and len(b)==1:continue
 for j in range(n):
  k=(j+1)%n
  if len(a)==1:f.append((a[0],b[j],b[k]))
  elif len(b)==1:f.append((a[j],b[0],a[k]))
  else:f.append((a[j],b[j],b[k],a[k]))
shell=mesh('egg_blue',v,f)
for poly in shell.data.polygons:
 if poly.index>=outer_count:poly.flip()
# Low locating rim around the separate animal base; not an attachment.
rim=cyl('locating rim',12.4,.8,3.6);boolean(rim,cyl('rim bore',11.,.7,3.7),'DIFFERENCE');boolean(shell,rim,'UNION')
parts.append(shell)
placements.append({'name':shell.name,'kind':'shell'})

# Exact STL and viewer coordinates, flat-backed eye modules are separate color solids.
manifest={'version':3,'units':'mm','egg_height_mm':H,'animal_height_mm':32,'shell_wall_normal_mm':WALL,'groove_remaining_normal_mm':WEAK,'floor_mm':FLOOR,'seam_reference_height_mm':SEAM,'crack_knots_degrees_mm':CRACK_KNOTS,'crack_corner_rounding_degrees':1,'groove_half_width_mm':GROOVE_HALF_WIDTH,'pause_candidate_mm':PAUSE,'seat_inner_radius_mm':11,'review_only':True,'placements':placements,'parts':[]}
for o in parts:
 if o.name!='egg_blue':
  for ext in ('.stl','.json'):shutil.copyfile(P.parent/'cad-v2'/(o.name+ext),OUT/(o.name+ext))
  manifest['parts'].append(next(p for p in previous['parts'] if p['name']==o.name))
  print('PRESERVED',o.name,flush=True)
  continue
 select(o);bpy.ops.object.transform_apply(location=True,rotation=True,scale=True)
 bm=bmesh.new();bm.from_mesh(o.data);bmesh.ops.triangulate(bm,faces=list(bm.faces));bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=1e-5);bmesh.ops.dissolve_degenerate(bm,dist=1e-5,edges=list(bm.edges));bm.to_mesh(o.data);bm.free();check_closed(o,'v3 export')
 o.data.calc_loop_triangles();verts=[tuple(v.co) for v in o.data.vertices];tris=[tuple(t.vertices) for t in o.data.loop_triangles]
 color='blue' if o.name=='egg_blue' else 'pink' if o.name.endswith('pink') else 'white' if o.name.endswith('white') else 'black'
 with (OUT/(o.name+'.stl')).open('wb') as f:
  f.write(b'Original Raven Cat CAD v3; mm'.ljust(80,b'\0'));f.write(struct.pack('<I',len(tris)))
  for tri in tris:
   a,b,c=(Vector(verts[i]) for i in tri);no=(b-a).cross(c-a).normalized();f.write(struct.pack('<12fH',*no,*a,*b,*c,0))
 (OUT/(o.name+'.json')).write_text(json.dumps({'name':o.name,'positions':[x for v in verts for x in v],'indices':[x for t in tris for x in t]},separators=(',',':')))
 manifest['parts'].append({'name':o.name,'color':color,'triangles':len(tris)})
 print('EXPORTED',o.name,len(tris),flush=True)
# Generate the Hatched preview from the exported STL using nest_preview.py.
# Using one triangle-based boolean engine avoids Blender polygon triangulation slivers.
manifest['previews']={'hatched':'egg_nest_preview','meaning':'Actual shell intersected with the designed crack path; not fracture simulation.'}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2))
# Assembled editable Blender review; exported STL coordinates remain print orientations.
for o in parts:
 if o.name=='egg_blue':o.location.x=-26;other=copy(o,'cat shell');other.location.x=26;continue
 p=next(p for p in placements if p['name']==o.name);x=-26 if p['kind']=='raven' else 26
 if 'eye_origin' in p:
  cx,back,cz=p['eye_origin'];o.rotation_euler.x=math.pi/2;o.location=(x+cx,back,cz+FLOOR)
 else:o.location=(x,0,FLOOR)
for o in bpy.context.scene.objects:
 color='blue' if 'shell' in o.name or o.name=='egg_blue' else 'pink' if 'pink' in o.name else 'white' if 'white' in o.name else 'black'
 m=bpy.data.materials.get(color) or bpy.data.materials.new(color);m.diffuse_color={'blue':(.18,.52,.85,1),'pink':(.92,.31,.49,1),'white':(.95,.95,.9,1),'black':(.015,.015,.025,1)}[color];o.data.materials.clear();o.data.materials.append(m)
 for poly in o.data.polygons:poly.use_smooth=True
bpy.context.scene.unit_settings.system='METRIC';bpy.context.scene.unit_settings.scale_length=.001
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'raven-cat-eggs-v3.blend'))
print('V3 BUILD COMPLETE',flush=True)
