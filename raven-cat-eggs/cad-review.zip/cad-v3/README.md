# Raven and cat eggs v3 — design review

This revision makes the opening groove irregular, with unequal spacing and heights and softened corner tips. It preserves the original pink animal shapes and blue 55 mm eggs, adds white/black eyes, and changes the assembly to separately printed loose animals. It is ready for geometry and appearance review, not physical printing approval.

## How it works

1. Print the pink raven and cat bodies together, standing on their flat bases.
2. Print the four white/black eye modules together, flat backs down. Each module has two material STL files sharing coordinates. Keep them assembled in the slicer. Glue each module into its matching socket; nominal fitting allowance is 0.18 mm. A printed fitting trial is still needed.
3. Print both blue shells together. Candidate pause: completed height 39 mm. Insert the finished animals upright, with their bases inside the locating rims, then resume to close the crowns. Exact pause command, parked-head clearance, inactive nozzle clearance, insertion fit, and resumed travel paths require X2D slicing and inspection before this becomes a print recipe.
4. The proposed opening is hand pressure at the front thumb recess above the irregular groove. The top is intended to break away while the bottom remains a nest. This action, force, fracture edges, and nest durability have NOT been tested. Do not promise child usability from CAD alone.

The "Hatched" viewer mode uses a Boolean intersection of the actual shell STL and a cutting surface following the irregular groove. The nest preview is not a separate print part. Its cutting surface sits 0.005 mm above the groove center to avoid coincident triangles; Boolean slivers are simplified within 0.0001 mm. Neither offset predicts fracture behavior. It does not simulate fracture or predict the exact broken edge.

## Dimensions and rationale

- Egg outer height 55 mm, maximum width about 44.6 mm (6% wider than v1 to admit the raven at the insertion pause); two egg centers 52 mm apart in the assembled review. This is not the actual sliced production layout.
- Animal height 32 mm; resting base plane z=1.2 mm after insertion. Body STL base plane z=0.
- Normal shell thickness nominally 1.4 mm, reduced to 0.9 mm at a 1.2 mm wide triangular opening groove on an irregular path around z=20 mm; 1° corner smoothing softens its tips. The thumb recess is also limited to nominal 0.9 mm remaining wall. These are continuous surfaces without unsupported slit bridges.
- Floor 1.2 mm. Locating rim inner radius 11 mm, outer radius 12.4 mm, top z=3.6 mm. It locates the separately printed base; it does not bond the animal to the shell.
- Four colors over three batches: pink bodies; white/black eyes; blue shells. No AMS or equipment purchase assumed. This trades one unattended complete-egg print for finished faces and a truly separate animal.
- Shell profile uses normal offsets instead of the v1 constant radial wall. No minimum sliced extrusion width has been verified yet.

A simple section comparison gives a remaining thickness ratio 0.9/1.4 = 0.643. For a same-width rectangular section at equal material stress, bending moment capacity scales as thickness squared, giving 0.413. This is only a relative geometric weak-section check: it does not predict squeeze force, layer fracture, or reliability. The shell's geometry, material, and print direction make an opening prototype essential.

## Files and rebuild

Run Blender on the mini: `blender -b --python cad-v3/build.py`. The generator reuses helper functions and the approved shape recipe from `../cad-v1/build.py`, and preserves the approved v2 animal and eye meshes byte-for-byte. The v2 manifest and ten non-shell STL/JSON pairs are rebuild dependencies. Next run `python3 nest_preview.py`, then `python3 check.py` in cad-v3 in the farm Python environment (numpy, trimesh, manifold3d, scipy, rtree, networkx). It verifies solids, exact STL/viewer geometry, nonoverlap, cavity, and a straight vertical insertion envelope; all failures stop release.

The eye STLs are already flat-back-down. The manifest supplies their assembly transforms for the viewer. The editable Blender file shows the assembled eggs; its parts are NOT a sliced print plate. Existing v1 and v2 files are retained for rollback.

## Required before printing

Review appearance, prepare a single shell opening trial and eye-fit trial, run X2D slicing/bed/nozzle and print checks, inspect supports and pause paths, and provide Tom the complete physical readiness checklist. The user's single "ready" is still required before sending a print. No printer command has been issued.
