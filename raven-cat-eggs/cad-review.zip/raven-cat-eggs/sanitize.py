"""Repair STL serialization debris only; refuse anything beyond paired zero-volume triangles.
Run after build.py and before check.py. Also regenerates exact browser geometry.
"""
from pathlib import Path
import json,numpy as np,trimesh
P=Path(__file__).resolve().parent;report=[];manifest=json.loads((P/'manifest.json').read_text())
for row in manifest['parts']:
 name=row['name'];m=trimesh.load_mesh(P/(name+'.stl'),process=True)
 if name.endswith('_pink'):
  parts=m.split(only_watertight=False);solids=[]
  for part in parts:
   if len(part.faces)==2 and len(part.vertices)==3 and abs(part.volume)<1e-12:
    assert set(part.faces[0])==set(part.faces[1]),'Unexpected fragment'
    report.append({'part':name,'removed_double_triangle_area_mm2':float(part.area)})
   else: solids.append(part)
  assert len(solids)==1 and solids[0].is_volume,'Unexpected non-solid body; repair refused'
  m=solids[0]
  m.export(P/(name+'.stl'))
 # Round to the exact float32 coordinates serialized by STL, shared by web and Blender.
 v=np.asarray(m.vertices,dtype=np.float32);f=np.asarray(m.faces,dtype=np.int32)
 (P/(name+'.json')).write_text(json.dumps({'name':name,'positions':v.ravel().tolist(),'indices':f.ravel().tolist()},separators=(',',':')))
 row.update(vertices=len(v),triangles=len(f),bounds_mm=m.bounds.tolist())
(P/'manifest.json').write_text(json.dumps(manifest,indent=2));(P/'repair-report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
