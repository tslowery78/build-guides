# Raven & Cat surprise eggs — CAD review v1

Original parametric mesh CAD for two pink animals in blue break-once eggs, intended for one paired X2D plate. Tom approved the concept and requested these colors on 2026-11-15.

## Files
- build.py: original Blender Python construction; run `blender -b --python build.py`, then `python sanitize.py` and `python check.py` in an environment with trimesh, numpy and manifold3d.
- sanitize.py: checks exported STL serialization and repairs only isolated paired zero-volume triangles; final run required no repairs.
- raven-cat-eggs.blend: editable model scene, both eggs spaced 52 mm center-to-center.
- *_pink.stl: animal bodies, millimetres.
- *_blue_eyes.stl: eye accents. Each file intentionally contains two separate eye solids, fitted into the body.
- egg_blue.stl: one complete closed shell; use two copies for the pair.
- *.json: the same triangle geometry used by the web viewer. Geometry equality is checked against STL float32 coordinates.
- check.py / checks.json: independent mesh, color-overlap, shell cavity and clearance checks.

## Dimensions and choices
Eggs: 55 mm high, 42.08 mm widest diameter. Animals: 32 mm high, starting at z=0.6 mm. Paired bounding envelope: approximately 94.08 × 42.08 × 55 mm, before brim and purge tower. This envelope is not a sliced plate clearance check.

Pink PLA for animals; blue PLA for shells and eye accents. Two colors shared across both eggs. Full blue eyes avoid fragile separate pupil islands and a third filament. The raven has a broad curved beak, folded wings and merged feet. The cat has rounded triangular ears and a thick curled tail blended into its body.

Shell: 0.6 mm radial thickness and a 0.6 mm floor. The wall thickness measured normal to the surface varies, especially near the crown. The animal bases touch the sacrificial floor without volume overlap. The floor must peel/break away; this behavior is NOT yet tested.

## Review before printing
This is an appearance and geometry review, not a print-ready release. No sliced X2D project, nozzle mapping, filament grams, print time, bridging check, or physical shell-release result is claimed. Internal overhangs, top closure and shell breakability require a coupon and slicer inspection. Do not send these meshes directly to the printer without that preparation.

The web cutaway hides the front half of the complete shell for inspection; it does not alter the CAD file. The animal-only view hides the shells. Spin, drag, pinch and Reset operate on the actual exported meshes.

## Independent size check
A thin ellipsoid shell with radii 21.04, 21.04 and 27.5 mm gives approximately 4,039 mm³ at 0.6 mm thickness; this CAD shell is 3,968 mm³. Agreement within 2% supports the volume scale, not physical cracking behavior.
