import json, math
from pathlib import Path
import numpy as np
import trimesh
P=Path(__file__).resolve().parent
manifest=json.loads((P/'manifest.json').read_text()); rows=[]; failures=[]
meshes={}
for part in manifest['parts']:
 n=part['name']; m=trimesh.load_mesh(P/(n+'.stl'),process=True); meshes[n]=m
 # STL/JSON geometry equality checked after float32 conversion (STL storage precision).
 j=json.loads((P/(n+'.json')).read_text()); v=np.array(j['positions'],dtype=np.float32).reshape(-1,3); f=np.array(j['indices']).reshape(-1,3)
 raw=trimesh.load_mesh(P/(n+'.stl'),process=False)
 maxdiff=float(np.max(np.abs(raw.vertices-v[f].reshape(-1,3))))
 pieces=m.split(only_watertight=False)
 row={'part':n,'watertight':bool(m.is_watertight),'winding_consistent':bool(m.is_winding_consistent),'volume_mm3':float(m.volume),'components':len(pieces),'component_volumes_mm3':[float(p.volume) for p in pieces],'bounds_mm':m.bounds.tolist(),'web_stl_max_difference_mm':maxdiff}
 if not m.is_watertight or not m.is_winding_consistent or m.volume<=0: failures.append(n+': invalid solid')
 if maxdiff>1e-5: failures.append(n+': browser mesh mismatch')
 expected_components=1 if n.endswith('_pink') else 2
 if len(pieces)!=expected_components: failures.append(n+': unexpected disconnected pieces')
 rows.append(row); print(json.dumps(row),flush=True)
# Independent containment checks: cavity empty, floor solid, side wall solid.
egg=meshes['egg_blue']; points=np.array([[0,0,25],[0,0,.3],[20.4,0,23]])
# Ray casting without optional rtree: solid angle winding works for this small sample.
def winding_at(mesh,p):
 a,b,c=(mesh.triangles[:,i,:]-p for i in range(3))
 la,lb,lc=(np.linalg.norm(x,axis=1) for x in (a,b,c))
 num=np.einsum('ij,ij->i',a,np.cross(b,c))
 den=la*lb*lc+np.einsum('ij,ij->i',a,b)*lc+np.einsum('ij,ij->i',b,c)*la+np.einsum('ij,ij->i',c,a)*lb
 return float(np.sum(2*np.arctan2(num,den))/(4*math.pi))
windings=[winding_at(egg,p) for p in points]
if abs(windings[0])>.01: failures.append('egg cavity is not empty by oriented winding')
if abs(windings[1]-1)>.01: failures.append('egg floor is not solid')
if abs(windings[2]-1)>.01: failures.append('egg side wall is not solid')
# Exact boolean intersections of color solids; use signed shell solids after validity confirmed.
intersections={}; clearance={}
for kind in ('raven','cat'):
 a=meshes[kind+'_pink']; b=meshes[kind+'_blue_eyes']
 
 if not a.is_volume or not b.is_volume:
  failures.append(kind+': intersection check blocked by invalid volume'); continue
 q=trimesh.boolean.intersection([a,b],engine='manifold'); intersections[kind+'_pink_blue_mm3']=float(q.volume)
 if abs(q.volume)>.001: failures.append(kind+': colors overlap')
 for material,m in [('pink',a),('blue',b)]:
  q2=trimesh.boolean.intersection([m,egg],engine='manifold'); intersections[kind+'_'+material+'_shell_mm3']=float(q2.volume)
  if abs(q2.volume)>.001: failures.append(kind+': animal intersects shell')
 v=np.vstack([a.vertices,b.vertices]); z=v[:,2]
 radius=23.2*np.sqrt(np.maximum(0,1-((z-23)/32)**2))*(1-.25*z/55)
 c=radius-.6-np.linalg.norm(v[:,:2],axis=1); clearance[kind]=float(c.min())
 if c.min()<.5 or z.min()<.59999 or z.max()>54.4: failures.append(kind+': shell clearance failure')
report={'parts':rows,'shell_test_points':points.tolist(),'shell_windings':windings,'intersections':intersections,'min_radial_shell_clearance_mm':clearance,'paired_envelope_mm':[52+2*21.0401802063,2*21.0401802063,55],'floor_contact':'Animal bases touch the sacrificial floor at z=0.6 mm; release untested.','failures':failures}
(P/'checks.json').write_text(json.dumps(report,indent=2)); print(json.dumps(report,indent=2))
raise SystemExit(bool(failures))
