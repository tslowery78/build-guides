"""V2 original CAD. Blender on mini. Units mm; appearance/fit review, not print release."""
import bpy,bmesh,json,math,struct
from pathlib import Path
from mathutils import Vector
P=Path(__file__).resolve().parent
# Reuse our original geometry helpers, without executing the v1 scene build.
src=(P.parent/'cad-v1/build.py').read_text()
start=src.index(" # Blue eye inlays"); end=src.index("\ndef radius",start)
src=src[:start]+" return [o]\n"+src[end:]
exec(src[:src.index("parts=animal('raven')")])
OUT=P
original_radius=radius
def radius(z): return 1.06*original_radius(z)
H=55.; FLOOR=1.2; SEAT=1.2; PAUSE=39.; WALL=1.4; WEAK=.9; SEAM=20.
parts=[]; placements=[]
def read(name):
 j=json.loads((P.parent/'cad-v1'/(name+'.json')).read_text()); v=list(zip(*[iter(j['positions'])]*3)); f=list(zip(*[iter(j['indices'])]*3))
 o=mesh(name,v,f)
 for x in o.data.vertices: x.co.z-=.6
 return o

def cube(name,center,size):
 bpy.ops.mesh.primitive_cube_add(size=1,location=center);o=bpy.context.object;o.name=name;o.scale=size;select(o);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return o

def copy(o,name):
 q=o.copy();q.data=o.data.copy();bpy.context.collection.objects.link(q);q.name=name;return q

for kind in ('raven','cat'):
 body=animal(kind)[0]
 for vertex in body.data.vertices: vertex.co.z-=FLOOR
 old=read(kind+'_blue_eyes')
 eye_params=[]
 for side in (-1,1):
  vs=[v.co for v in old.data.vertices if v.co.x*side>0]
  lo=Vector([min(v[i] for v in vs) for i in range(3)]);hi=Vector([max(v[i] for v in vs) for i in range(3)])
  eye_params.append(((lo+hi)/2,(hi-lo)/2,side))
 # Original sockets are filled before cutting clearance-fit sockets.
 bpy.data.objects.remove(old,do_unlink=True)
 parts.append(body)
 for c,s,side in eye_params:
  suffix='left' if side<0 else 'right'
  name=f'{kind}_eye_{suffix}'
  back=c.y+.4
  socket=ell('eye socket',c,tuple(t+.18 for t in s))
  boolean(socket,cube('socket back',(0,back+.18+50,25),(100,100,100)),'DIFFERENCE')
  boolean(body,socket,'DIFFERENCE')
  # Partition one analytical dome at a shared planar interface; identical interface
  # vertices avoid independently rounded boolean boundaries between eye colors.
  def dome_piece(label,t0,t1,steps):
   vertices=[];rings=[];N=80
   for i in range(steps+1):
    t=t0+(t1-t0)*i/steps
    if abs(t)<1e-9:
     rings.append([len(vertices)]);vertices.append((c.x,c.y-s.y,c.z));continue
    ids=[]
    for j in range(N):
     a=2*math.pi*j/N;ids.append(len(vertices));vertices.append((c.x+s.x*math.sin(t)*math.cos(a),c.y-s.y*math.cos(t),c.z+s.z*math.sin(t)*math.sin(a)))
    rings.append(ids)
   faces=[]
   if len(rings[0])>1:faces.append(tuple(reversed(rings[0])))
   for aa,bb in zip(rings[:-1],rings[1:]):
    for j in range(N):
     k=(j+1)%N
     faces.append((aa[0],bb[j],bb[k]) if len(aa)==1 else (aa[j],bb[j],bb[k],aa[k]))
   faces.append(tuple(rings[-1]))
   return mesh(label,vertices,faces)
  split=.8
  white=dome_piece(name+'_white',split,math.acos(-.4/s.y),40)
  black=dome_piece(name+'_black',0,split,24)
  for o in (white,black):
   # Export each eye module flat-back-down. Viewer restores exact assembly transform.
   for v in o.data.vertices:
    w=o.matrix_world@v.co;v.co=Vector((w.x-c.x,w.z-c.z,back-w.y))
   o.location=(0,0,0);o.rotation_euler=(0,0,0);o.scale=(1,1,1)
   parts.append(o)
   placements.append({'name':o.name,'kind':kind,'eye_origin':[c.x,back,c.z], 'assembly_z':FLOOR})
 placements.append({'name':body.name,'kind':kind,'assembly_z':FLOOR})

# Smooth ovoid with inner surface offset in the meridian normal direction.
def dr(z):
 t=max(1e-8,1-((z-23)/32)**2)
 return 1.06*23.2*(-(z-23)/(1024*math.sqrt(t))*(1-.25*z/H)-math.sqrt(t)*.25/H)
def inner(z):
 d=dr(z);n=math.sqrt(1+d*d)
 return radius(z)-WALL/n,z+WALL*d/n

def groove(z):
 return .5*max(0,1-abs(z-SEAM)/1.2)
# The shallow front thumb recess meets the circumferential opening groove.
def thumb(z,a):
 da=math.atan2(math.sin(a+math.pi/2),math.cos(a+math.pi/2))
 return .5*max(0,1-(da/.24)**2)*max(0,1-((z-22.1)/2.1)**2)

n=160;zs=sorted(set([i*H/220 for i in range(221)]+[18.8,20,21.2,22.1,24.2,39]))
# Closed meridian has two axis segments; normals must orient cavity inward.
v=[];rings=[]
def ring(r,z):
 if abs(r)<1e-7: rings.append([len(v)]);v.append((0,0,z))
 else:
  ids=[]
  for j in range(n):
   a=j*2*math.pi/n;ids.append(len(v));v.append((r*math.cos(a),r*math.sin(a),z))
  rings.append(ids)
ring(0,0)
for z in zs[:-1]:
 ids=[];d=dr(z);norm=math.sqrt(1+d*d)
 for j in range(n):
  a=j*2*math.pi/n;cut=max(groove(z),thumb(z,a));r=radius(z)-cut/norm;zz=z+cut*d/norm
  ids.append(len(v));v.append((r*math.cos(a),r*math.sin(a),zz))
 rings.append(ids)
ring(0,H);outer_count=n*(len(zs))
ring(0,H-WALL)
# Stop inner offset at the horizontal floor, interpolate exact intersection.
inner_points=[inner(z) for z in zs[:-1]]
for i,(r,z) in enumerate(inner_points):
 if z>=FLOOR:
  ra,za=inner_points[i-1];rf=ra+(r-ra)*(FLOOR-za)/(z-za);inner_points= [(rf,FLOOR)]+inner_points[i:];break
for r,z in reversed(inner_points):ring(r,z)
ring(0,FLOOR)
f=[]
for a,b in zip(rings[:-1],rings[1:]):
 if len(a)==1 and len(b)==1:continue
 for j in range(n):
  k=(j+1)%n
  if len(a)==1:f.append((a[0],b[j],b[k]))
  elif len(b)==1:f.append((a[j],b[0],a[k]))
  else:f.append((a[j],b[j],b[k],a[k]))
shell=mesh('egg_blue',v,f)
for poly in shell.data.polygons:
 if poly.index>=outer_count:poly.flip()
# Low locating rim around the separate animal base; not an attachment.
rim=cyl('locating rim',12.4,.8,3.6);boolean(rim,cyl('rim bore',11.,.7,3.7),'DIFFERENCE');boolean(shell,rim,'UNION')
parts.append(shell)
placements.append({'name':shell.name,'kind':'shell'})

# Exact STL and viewer coordinates, flat-backed eye modules are separate color solids.
manifest={'version':2,'units':'mm','egg_height_mm':H,'animal_height_mm':32,'shell_wall_normal_mm':WALL,'groove_remaining_normal_mm':WEAK,'floor_mm':FLOOR,'seam_height_mm':SEAM,'pause_candidate_mm':PAUSE,'seat_inner_radius_mm':11,'review_only':True,'placements':placements,'parts':[]}
for o in parts:
 select(o);bpy.ops.object.transform_apply(location=True,rotation=True,scale=True)
 bm=bmesh.new();bm.from_mesh(o.data);bmesh.ops.triangulate(bm,faces=list(bm.faces));bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=1e-5);bmesh.ops.dissolve_degenerate(bm,dist=1e-5,edges=list(bm.edges));bm.to_mesh(o.data);bm.free();check_closed(o,'v2 export')
 o.data.calc_loop_triangles();verts=[tuple(v.co) for v in o.data.vertices];tris=[tuple(t.vertices) for t in o.data.loop_triangles]
 color='blue' if o.name=='egg_blue' else 'pink' if o.name.endswith('pink') else 'white' if o.name.endswith('white') else 'black'
 with (OUT/(o.name+'.stl')).open('wb') as f:
  f.write(b'Original Raven Cat CAD v2; mm'.ljust(80,b'\0'));f.write(struct.pack('<I',len(tris)))
  for tri in tris:
   a,b,c=(Vector(verts[i]) for i in tri);no=(b-a).cross(c-a).normalized();f.write(struct.pack('<12fH',*no,*a,*b,*c,0))
 (OUT/(o.name+'.json')).write_text(json.dumps({'name':o.name,'positions':[x for v in verts for x in v],'indices':[x for t in tris for x in t]},separators=(',',':')))
 manifest['parts'].append({'name':o.name,'color':color,'triangles':len(tris)})
 print('EXPORTED',o.name,len(tris),flush=True)
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2))
# Assembled editable Blender review; exported STL coordinates remain print orientations.
for o in parts:
 if o.name=='egg_blue':o.location.x=-26;other=copy(o,'cat shell');other.location.x=26;continue
 p=next(p for p in placements if p['name']==o.name);x=-26 if p['kind']=='raven' else 26
 if 'eye_origin' in p:
  cx,back,cz=p['eye_origin'];o.rotation_euler.x=math.pi/2;o.location=(x+cx,back,cz+FLOOR)
 else:o.location=(x,0,FLOOR)
for o in bpy.context.scene.objects:
 color='blue' if 'shell' in o.name or o.name=='egg_blue' else 'pink' if 'pink' in o.name else 'white' if 'white' in o.name else 'black'
 m=bpy.data.materials.get(color) or bpy.data.materials.new(color);m.diffuse_color={'blue':(.18,.52,.85,1),'pink':(.92,.31,.49,1),'white':(.95,.95,.9,1),'black':(.015,.015,.025,1)}[color];o.data.materials.clear();o.data.materials.append(m)
 for poly in o.data.polygons:poly.use_smooth=True
bpy.context.scene.unit_settings.system='METRIC';bpy.context.scene.unit_settings.scale_length=.001
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'raven-cat-eggs-v2.blend'))
print('V2 BUILD COMPLETE',flush=True)
