import json,math
from pathlib import Path
import numpy as np,trimesh
P=Path(__file__).resolve().parent
manifest=json.loads((P/'manifest.json').read_text());fail=[];checks=[];meshes={};rows=[]
def check(name,condition,data=None):
 checks.append({'name':name,'pass':bool(condition),'data':data})
 if not condition:fail.append(name)
for part in manifest['parts']:
 n=part['name'];m=trimesh.load_mesh(P/(n+'.stl'),process=True);meshes[n]=m
 check(n+' watertight volume',m.is_volume)
 pieces=m.split(only_watertight=False)
 expected=2 if n=='egg_blue' else 1
 check(n+' component count',len(pieces)==expected,len(pieces))
 j=json.loads((P/(n+'.json')).read_text());v=np.array(j['positions'],dtype=np.float32).reshape(-1,3);f=np.array(j['indices']).reshape(-1,3)
 raw=trimesh.load_mesh(P/(n+'.stl'),process=False)
 check(n+' STL/viewer equality',np.array_equal(raw.vertices.astype(np.float32),v[f].reshape(-1,3)))
 # Rewrite viewer using exact STL floats, preserving STL triangle order without mesh changes.
 (P/(n+'.json')).write_text(json.dumps({'name':n,'positions':np.array(m.vertices,dtype=np.float32).ravel().tolist(),'indices':m.faces.ravel().tolist()},separators=(',',':')))
 rows.append({'name':n,'volume_mm3':float(m.volume),'bounds_mm':m.bounds.tolist(),'components':len(pieces)})
 if 'eye' in n:check(n+' eye flat print bounds',m.bounds[0,2]>=-1e-5)
def intersect(a,b):return float(trimesh.boolean.intersection([a,b],engine='manifold').volume)
def assembled(n):
 m=meshes[n].copy();p=next(p for p in manifest['placements'] if p['name']==n)
 if 'eye_origin' in p:
  cx,back,cz=p['eye_origin'];v=m.vertices.copy();m.vertices=np.column_stack((v[:,0]+cx,back-v[:,2],v[:,1]+cz+1.2))
 else:m.apply_translation([0,0,1.2])
 return m
shell=meshes['egg_blue'];report={'parts':rows}
# Orientated winding rejects an inside-out cavity.
def winding(p):
 a,b,c=(shell.triangles[:,i,:]-p for i in range(3));la,lb,lc=(np.linalg.norm(x,axis=1) for x in (a,b,c));num=np.einsum('ij,ij->i',a,np.cross(b,c));den=la*lb*lc+np.einsum('ij,ij->i',a,b)*lc+np.einsum('ij,ij->i',b,c)*la+np.einsum('ij,ij->i',c,a)*lb
 return float(np.sum(2*np.arctan2(num,den))/(4*math.pi))
for name,p,expected in [('cavity',[0,0,25],0),('floor',[0,0,.6],1),('seat rim',[11.7,0,2],1)]:
 w=winding(np.array(p));check(name+' winding',abs(w-expected)<.01,w)
# Opening after layer 39: smallest actual inner-section radial coordinate, not nominal radius.
section=shell.section(plane_origin=[0,0,39],plane_normal=[0,0,1]);opening=min(np.linalg.norm(section.vertices[:,:2],axis=1));report['pause_opening_radius_mm']=float(opening)
for kind in ('raven','cat'):
 names=[r['name'] for r in manifest['parts'] if r['name'].startswith(kind)]
 am=[assembled(n) for n in names];v=np.vstack([m.vertices for m in am]);rad=np.linalg.norm(v[:,:2],axis=1).max();gap=opening-rad;headroom=39-v[:,2].max()
 check(kind+' straight vertical insertion clearance',gap>.75, float(gap))
 check(kind+' headroom below candidate pause',headroom>5,float(headroom))
 check(kind+' animal shell no volume intersection',all(abs(intersect(a,shell))<.001 for a in am))
 # Translate animal vertically from its seated location to wholly above the opening;
 # a cylinder envelope smaller than opening proves the straight loading passage.
 body=am[0]
 for n,a in zip(names,am):
  if n.endswith('pink'):continue
  check(n+' no body interference',abs(intersect(body,a))<.001)
 for side in ('left','right'):
  a=meshes[f'{kind}_eye_{side}_white'];b=meshes[f'{kind}_eye_{side}_black'];check(kind+' '+side+' eye colors nonoverlap',abs(intersect(a,b))<.001)
  union=trimesh.boolean.union([a,b],engine='manifold');check(kind+' '+side+' eye assembled solid',union.is_volume and len(union.split())==1)
report.update(checks=checks,failures=fail,limits=['Opening force, handling strength, fracture edges and printed eye fit untested.','Loading clearance assumes animal upright; nozzle and toolhead paths require sliced inspection.','Nominal weak section 0.9 mm normal vs main shell 1.4 mm; not a validated break force.'])
(P/'checks.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2));raise SystemExit(bool(fail))
