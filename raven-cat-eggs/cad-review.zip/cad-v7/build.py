"""v7 sacrificial shell and internal branching trees, mm; run on CAD farm.

Preserves v4 animals. Thin walls are intentional experimental breakaway features,
not structural walls. Slice continuity and physical opening must be checked.
"""
from pathlib import Path
import math,json
import numpy as np
import trimesh as tm
import manifold3d as md
P=Path(__file__).resolve().parent
M=json.loads((P/'input/manifest.json').read_text())
H=55.; FLOOR=1.2; WALL=.6; WEAK=.4; HOLE=7.6
N=240
knots=np.array(M['crack_knots_degrees_mm'])
def radius(z):return 1.06*23.2*math.sqrt(max(0,1-((z-23)/32)**2))*(1-.25*z/H)
def dr(z):
 t=max(1e-8,1-((z-23)/32)**2)
 return 1.06*23.2*(-(z-23)/(1024*math.sqrt(t))*(1-.25*z/H)-math.sqrt(t)*.25/H)
def raw(a):return float(np.interp(math.degrees(a)%360,knots[:,0],knots[:,1]))
def crack(a):
 d=math.pi/180
 return (raw(a-d)+2*raw(a)+raw(a+d))/4
def thick(z):return WALL+.3*max(0,min(1,(6-z)/2))
def inner(z):
 d=dr(z);n=math.hypot(1,d);t=thick(z)
 return radius(z)-t/n,z+t*d/n
def solid(m):return md.Manifold(md.Mesh(vert_properties=np.asarray(m.vertices,dtype=np.float32),tri_verts=np.asarray(m.faces,dtype=np.uint32)))
def mesh(s, simplify=False):
 a=(s.simplify(.0001) if simplify else s).to_mesh();m=tm.Trimesh(a.vert_properties[:,:3],a.tri_verts,process=True,validate=True)
 if not m.is_volume:
  counts=np.bincount(m.edges_unique_inverse);bad=m.edges_unique[counts!=2];print('BAD',len(bad),m.vertices[bad[:20]].tolist(),flush=True)
  raw=s.to_mesh();rm=tm.Trimesh(raw.vert_properties[:,:3],raw.tri_verts,process=True,validate=True);print('RAW',rm.is_volume,rm.is_watertight,flush=True)
 assert m.is_volume,(s.status(),m.is_watertight)
 return m
def cyl(r,z0,z1):return md.Manifold.cylinder(z1-z0,r,r,128).translate((0,0,z0))
def export(name,s,color,kind):
 m=mesh(s, name=='egg_blue' or name.endswith('_trees'));m.export(P/(name+'.stl'));m=tm.load_mesh(P/(name+'.stl'),process=True);assert m.is_volume
 (P/(name+'.json')).write_text(json.dumps(dict(name=name,positions=m.vertices.ravel().tolist(),indices=m.faces.ravel().tolist()),separators=(',',':')))
 M['parts'].append(dict(name=name,color=color,triangles=len(m.faces)))
 M['placements'].append(dict(name=name,kind=kind,assembly_z=0))
 print(name,len(m.faces),round(m.volume,3),flush=True)
 return m
zs=sorted(set([i*H/220 for i in range(221)]+[18.8,19.4,20,20.6,21.2,22.1,24.2,39]))
v=[];rings=[]
def ring(r,z):
 if abs(r)<1e-7:rings.append([len(v)]);v.append((0,0,z));return
 ids=[]
 for j in range(N):
  a=j*2*math.pi/N;ids.append(len(v));v.append((r*math.cos(a),r*math.sin(a),z))
 rings.append(ids)
ring(0,0)
for z in zs[:-1]:
 ids=[]
 for j in range(N):
  a=j*2*math.pi/N;w=max(0,min(1,(z-9)/9.8,(31-z)/9.8));zz=z+(crack(a)-20)*w
  d=dr(zz);n=math.hypot(1,d)
  groove=(WALL-WEAK)*max(0,1-abs(zz-crack(a))/.6)
  da=math.atan2(math.sin(a+math.pi/2),math.cos(a+math.pi/2))
  thumb=.14*max(0,1-(da/.24)**2)*max(0,1-((zz-crack(a)-2.1)/2.1)**2)
  cut=max(groove,thumb);r=radius(zz)-cut/n;zz+=cut*d/n
  ids.append(len(v));v.append((r*math.cos(a),r*math.sin(a),zz))
 rings.append(ids)
ring(0,H);ring(0,H-WALL)
pts=[inner(z) for z in zs[:-1]]
for i,(r,z) in enumerate(pts):
 if z>=FLOOR:
  ra,za=pts[i-1];pts=[(ra+(r-ra)*(FLOOR-za)/(z-za),FLOOR)]+pts[i:];break
for r,z in reversed(pts):ring(r,z)
ring(0,FLOOR)
faces=[]
for a,b in zip(rings[:-1],rings[1:]):
 if len(a)==len(b)==1:continue
 for j in range(N):
  k=(j+1)%N
  if len(a)==1:faces.append((a[0],b[j],b[k]))
  elif len(b)==1:faces.append((a[j],b[0],a[k]))
  else:faces.extend([(a[j],b[j],b[k]),(a[j],b[k],a[k])])
# Two closed boundary components: outer outward, cavity inward. Generic
# fix_normals would wrongly orient the cavity outward and fill the egg.
base=tm.Trimesh(v,np.asarray(faces)[:,::-1],process=True);assert base.is_volume
assert 3000 < base.volume < 15000, base.volume
shell=solid(base)-cyl(HOLE,-1,1.3)
# Small rounded vertical slit crosses the front groove. Its 0.8 mm width bridges
# locally at its rounded top; it does not create a detached upper shell.
cz=crack(-math.pi/2)
cap=md.Manifold.cylinder(6,.4,.4,48).rotate((90,0,0))
slot=md.Manifold.batch_hull([cap.translate((0,-19,cz-.8)),cap.translate((0,-19,cz+.8))])
print('VOLUMES base/shell/slot',base.volume,shell.volume(),slot.volume(), 'local volumes',[(solid(base)^md.Manifold.sphere(.1).translate(c)).volume() for c in [(0,0,20),(0,-19,20),(0,-22,20)]],flush=True)
shell=shell-slot
print('after slot',shell.volume(),flush=True)
# Trees start at the INSIDE WALL, fork, and end in thin tips on each animal.
# Both trunks and branches remain below the crack line, so they cannot brace it.
outer=solid(max(base.split(only_watertight=True),key=lambda m:m.volume))
M.update(version=7,shell_wall_normal_mm=WALL,groove_remaining_normal_mm=WEAK,
 lower_wall_normal_mm=.9,lower_wall_transition_z_mm=[4,6],groove_half_width_mm=.6,
 crack_start_slot_mm=[.8,2.4],parts=[],placements=[],review_only=True,
 physical_opening_test='v4 required a vise; v7 unprinted',internal_trees={},tree_color='pink')
M.pop('foot_links',None)
export('egg_blue',shell,'blue','shell')
def disc(c,r):return md.Manifold.cylinder(.04,r,r,48).translate((c[0],c[1],c[2]-.02))
def branch(a,b,ra,rb):return md.Manifold.batch_hull([disc(a,ra),disc(b,rb)])
def flank(m,y,z,side):
 # Exact ray/triangle intersection along X, without a spatial-index dependency.
 t=m.triangles;p=t[:,0];e=t[:,1]-p;f=t[:,2]-p
 det=e[:,1]*f[:,2]-e[:,2]*f[:,1];valid=abs(det)>1e-12
 u=np.zeros(len(t));v=np.zeros(len(t));dy=y-p[:,1];dz=z-p[:,2]
 u[valid]=(dy[valid]*f[valid,2]-dz[valid]*f[valid,1])/det[valid]
 v[valid]=(e[valid,1]*dz[valid]-e[valid,2]*dy[valid])/det[valid]
 valid &= (u>=-1e-9)&(v>=-1e-9)&(u+v<=1+1e-9)
 xs=(p[:,0]+u*e[:,0]+v*f[:,0])[valid]
 assert len(xs)>0
 return float(max(xs) if side>0 else min(xs))
def first_hit(m,start,end):
 d=end-start;length=np.linalg.norm(d);d=d/length
 tri=m.triangles;e1=tri[:,1]-tri[:,0];e2=tri[:,2]-tri[:,0]
 h=np.cross(np.broadcast_to(d,e2.shape),e2);a=np.einsum('ij,ij->i',e1,h)
 valid=abs(a)>1e-10;inv=np.zeros(len(a));inv[valid]=1/a[valid]
 ss=start-tri[:,0];u=inv*np.einsum('ij,ij->i',ss,h);q=np.cross(ss,e1)
 vv=inv*np.einsum('j,ij->i',d,q);t=inv*np.einsum('ij,ij->i',e2,q)
 valid &= (u>=0)&(vv>=0)&(u+vv<=1)&(t>0)&(t<=length)
 assert valid.any(), 'No incoming contact intersection'
 return start+d*min(t[valid]),d
for kind in ('raven','cat'):
 original=tm.load_mesh(P/'input'/(kind+'_pink.stl'),process=True);body=solid(original)
 trees=None;stems=None;targets=[];segments=[]
 for side in (-1,1):
  root=np.array([side*17.4/math.sqrt(2),17.4/math.sqrt(2),1.6]);fork=np.array([side*14.75/math.sqrt(2),14.75/math.sqrt(2),4.3])
  tree=branch(root,fork,.50,.65);stem=tree;segments.append([root.tolist(),fork.tolist()])
  for y in (3.8,4.8):
   tip_z=14.7
   surface=np.array([flank(original,y,tip_z,side),y,tip_z])
   proposed=surface+np.array([-side*.30,0,0])
   surface,direction=first_hit(original,fork,proposed)
   target=surface+direction*.18
   start=target+(fork-target)/np.linalg.norm(fork-target)*3.5
   limb=branch(fork,start,.65,.5)
   stem=stem+limb
   tree=tree+limb+branch(start,target,.40,.40)
   targets.append(surface.tolist());segments.extend([[fork.tolist(),start.tolist()],[start.tolist(),target.tolist()]])
  trees=tree if trees is None else trees+tree
  stems=stem if stems is None else stems+stem
 # Trim the roots at the exterior surface and against already-assigned colors.
 # Animal geometry is preserved; tree tips meet its surface without overlap.
 raw_trees=trees^outer
 tree=raw_trees-shell-body
 export(kind+'_pink',body,'pink',kind)
 export(kind+'_blue_eyes',solid(tm.load_mesh(P/'input'/(kind+'_blue_eyes.stl'),process=True)),'blue',kind)
 export(kind+'_blue_trees',tree,'pink',kind)
 M['parts'][-1]['role']='supports'
 M['internal_trees'][kind]=dict(count=2,tip_count=4,tip_diameter_mm=.80,tip_neck_length_mm=3.5,
  thick_branch_animal_overlap_mm3=(stems^body).volume(),root_z_mm=1.6,fork_z_mm=4.3,tip_surface_z_mm=14.7,contact_points_mm=targets,segments_mm=segments)
M['previews']={'hatched':'egg_nest_preview','meaning':'Illustrative cut at groove; trees remain attached; fracture and release untested.'}
(P/'manifest.json').write_text(json.dumps(M,indent=2))
print('v7 built: internal shell-wall trees, no foot tabs; physical release untested',flush=True)
