from pathlib import Path
import json,math
import numpy as np,trimesh as tm,manifold3d as md
P=Path(__file__).resolve().parent;M=json.loads((P/'manifest.json').read_text());checks=[]
def check(n,c,**d):
 checks.append(dict(name=n,pass_=bool(c),**d));print(n,bool(c),d,flush=True)
def sol(m):return md.Manifold(md.Mesh(vert_properties=np.asarray(m.vertices,dtype=np.float32),tri_verts=np.asarray(m.faces,dtype=np.uint32)))
def load(n):return tm.load_mesh(P/(n+'.stl'),process=True)
def count(s):return len([q for q in s.decompose() if q.volume()>1e-6])
parts={p['name']:load(p['name']) for p in M['parts']}
for n,m in parts.items():
 check(n+' closed volume',m.is_volume,volume_mm3=float(m.volume))
 j=json.loads((P/(n+'.json')).read_text());q=tm.Trimesh(np.array(j['positions']).reshape(-1,3),np.array(j['indices']).reshape(-1,3),process=True)
 check(n+' exact preview',np.array_equal(m.triangles,q.triangles))
S=sol(parts['egg_blue'])
nj=json.loads((P/'egg_nest_preview.json').read_text());N=sol(tm.Trimesh(np.array(nj['positions']).reshape(-1,3),np.array(nj['indices']).reshape(-1,3),process=True))
pairs={'pink':[],'blue':[]}
for kind,x in [('raven',-26),('cat',26)]:
 pink=parts[kind+'_pink'];blue=parts[kind+'_blue_eyes'];tree=parts[kind+'_blue_trees'];A=sol(pink)+sol(blue);T=sol(tree)
 original=sol(tm.load_mesh(P/'input'/(kind+'_pink.stl'),process=True))
 check(kind+' animal volume preserved exactly',abs((original-sol(pink)).volume())+abs((sol(pink)-original).volume())<1e-6)
 check(kind+' thick branches do not weld to animal',abs(M['internal_trees'][kind]['thick_branch_animal_overlap_mm3'])<1e-6,overlap_mm3=M['internal_trees'][kind]['thick_branch_animal_overlap_mm3'])
 check(kind+' two branching trees',count(T)==2,count=count(T))
 check(kind+' trees bonded to shell interior',count(T+S)==1)
 check(kind+' trees bonded to animal',count(T+A)==1)
 check(kind+' no foot attachments',count(S+A)==2)
 check(kind+' disjoint material interiors',abs((T^A).volume())+abs((S^A).volume())+abs((S^T).volume())<1e-5)
 check(kind+' trees below irregular crack',tree.bounds[1,2]<17.0,max_z_mm=float(tree.bounds[1,2]))
 for i,point in enumerate(M['internal_trees'][kind]['contact_points_mm']):
  region=md.Manifold.sphere(.75,32).translate(point)
  patch=T^region
  check(f'{kind} tip {i+1} attached',count(A+patch)==1 and patch.volume()>.001,local_region_components=count((A+T)^region),animal_plus_tip_components=count(A+patch),tip_patch_volume_mm3=patch.volume())
 for i,(a,b) in enumerate(M['internal_trees'][kind]['segments_mm']):
  horizontal=math.hypot(b[0]-a[0],b[1]-a[1]);rise=b[2]-a[2]
  check(f'{kind} branch {i+1} rises at least 45 degrees',rise>=horizontal,rise_mm=rise,horizontal_mm=horizontal)
 volumes=[(A.translate((0,0,float(z)))^N).volume() for z in np.arange(0,24,.5)]
 check(kind+' extracts after trees removed',max(volumes)<1e-5,max_overlap_mm3=max(volumes))
 for m,c in [(pink,'pink'),(blue,'blue'),(tree,'pink'),(parts['egg_blue'],'blue')]:
  q=m.copy();q.apply_translation((x,0,0));pairs[c].append(q)
for col,items in pairs.items():
 joined=sol(items[0])
 for item in items[1:]:joined=joined+sol(item)
 mm=joined.to_mesh();tm.Trimesh(mm.vert_properties[:,:3],mm.tri_verts,process=True).export(P/('pair_'+col+'.stl'))
check('thin shell and crack retained',M['shell_wall_normal_mm']==.6 and M['groove_remaining_normal_mm']==.4)
check('one complete paired run',M['print_in_place'] and M['no_insertion_pause'])
report=dict(checks=checks,passed=all(c['pass_'] for c in checks),limitations=['Tree tip release and hand opening untested.','No fracture force calculation.','Vertical extraction assumes trees removed, sampled every 0.5 mm.'])
(P/'checks.json').write_text(json.dumps(report,indent=2));assert report['passed']
