# Raven and cat eggs v7 — internal shell-wall trees

Tom clarified that the supports should branch between the animal and the inside eggshell wall. v5's foot tabs were the wrong interpretation and are removed.

Each egg now contains two small pink trees, one on each rear side. Each starts at the inside shell wall near z=1.6 mm, forks near z=4.3 mm, and reaches two spots on the animal's rear flank at about z=13–15 mm. The four tips per animal are 0.8 mm in diameter, with 3.5 mm long narrow necks before the contact. The trunk/branch diameters are about 1.0–1.3 mm. Each contact is positioned using the first intersection of its incoming branch with the actual animal mesh, so thick stems stay clear. Everything stays below the irregular crack line (minimum about z=17.8 mm), so trees do not connect the lid to the lower nest.

The pink animals themselves are unchanged from v4, including the feet that start on the build plate. The trees print in the animal’s pink filament and are unioned with the animal in the print mesh; the broad roots meet the blue shell. The tree roots bond to the interior shell wall and the narrow tips meet the animal's sides. These are explicitly modeled branching supports, not automatic slicer-generated trees. The physical strength of those joints is untested.

The thin v5 shell is retained: 0.6 mm main wall, 0.4 mm remaining at the irregular crack, 0.9 mm lower wall, 1.2 mm floor. The front has the small rounded crack-start slot. Both complete eggs still print in one uninterrupted two-color run, with blue left/Main and pink right/Auxiliary, no assembly or insertion pause.

The viewer's Trees button hides the animals and upper/front shell to expose the roots, forks and tips. Cutaway shows the trees with the animals present. Hatched is only an illustrative cut, not a fracture or release simulation.

Before another print: review the CAD, check the new branch toolpaths, and confirm the complete physical setup. Opening by hand and snapping the tree tips free must still be tested. The printed v4 needed a vise, so a pass on geometry or slicing does not establish easy opening. No v7 print has been sent.


## Reason for v7

The v6 slicer dropped parts of the 0.48 mm circular tips. The tip diameter is now 0.8 mm; the 3.5 mm neck length and tree routing remain. The earlier centerline-only audit also incorrectly rejected hollow trunk centers. The replacement checks actual nominal deposited area, consecutive-layer overlap, root-shell connection and each tip-body connection. Neither audit establishes physical release force.

Blue 0.8 mm tree contacts also lost several small end sections at the animal color boundary. Final v7 uses pink trees unioned with the animal material; the shell remains blue. This is a fabrication correction, with the same exterior animal geometry and tree routing. Historical tree STL asset filenames retain the `_blue_trees` suffix; manifest color and the paired print mesh explicitly assign them pink.

## Final candidate checks

62 geometry checks passed. Actual toolpath audit passed 386 tree cross-sections across 158 animal/layer combinations, including consecutive-layer overlap, four wall roots and all eight animal contacts. Minimum nominal deposited-area coverage was 58%; minimum adjacent-layer overlap 0.192 mm². The 14,794 shell samples had no missing paths; measured nominal bead unions 0.402–0.679 mm. Standard print_check has only the known 229 automatic nozzle-switch warning. Estimate 13,343 s (3 h 42 m 23 s), 43.51 g total: pink 21.42 g, blue 22.09 g. Hand opening and clean tip release remain untested. No v7 print sent.
