"""Original raven + cat surprise egg CAD. Run: blender -b --python build.py
Units are millimetres. No source meshes. Parts are generated from parameters.
This is a review candidate, not a validated print recipe.
"""
import bpy, bmesh, math, json, struct
from pathlib import Path
from mathutils import Vector
OUT=Path(__file__).resolve().parent
H=55.; FLOOR=.6; WALL=.6; ANIMAL_H=32.
PINK=(.92,.31,.49,1); BLUE=(.18,.52,.85,1)
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)

def select(o):
 bpy.ops.object.select_all(action='DESELECT'); o.select_set(True); bpy.context.view_layer.objects.active=o

def apply(o,m):
 select(o); name=m.name; bpy.ops.object.modifier_apply(modifier=name)
 if o.modifiers.get(name): raise RuntimeError('Modifier did not apply: '+o.name+' '+name)

def ell(name,c,s,rot=(0,0,0)):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=80,ring_count=48,location=c)
 o=bpy.context.object; o.name=name; o.scale=s; o.rotation_euler=rot
 select(o); bpy.ops.object.transform_apply(location=False,rotation=True,scale=True)
 return o

def tube(name,pts,r):
 cu=bpy.data.curves.new(name,'CURVE'); cu.dimensions='3D'; cu.resolution_u=12
 cu.bevel_depth=r; cu.bevel_resolution=4; cu.resolution_u=16; cu.use_fill_caps=True
 sp=cu.splines.new('BEZIER'); sp.bezier_points.add(len(pts)-1)
 for p,c in zip(sp.bezier_points,pts): p.co=c; p.handle_left_type='AUTO'; p.handle_right_type='AUTO'
 o=bpy.data.objects.new(name,cu); bpy.context.collection.objects.link(o); select(o); bpy.ops.object.convert(target='MESH')
 bm=bmesh.new(); bm.from_mesh(o.data); bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=1e-5); bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces)); bm.to_mesh(o.data); bm.free()
 return o

def mesh(name,v,f):
 me=bpy.data.meshes.new(name); me.from_pydata(v,[],f); me.update()
 o=bpy.data.objects.new(name,me); bpy.context.collection.objects.link(o)
 select(o); bpy.ops.object.mode_set(mode='EDIT'); bpy.ops.mesh.select_all(action='SELECT'); bpy.ops.mesh.normals_make_consistent(inside=False); bpy.ops.object.mode_set(mode='OBJECT')
 return o

def cyl(name,r,z0,z1):
 bpy.ops.mesh.primitive_cylinder_add(vertices=96,radius=r,depth=z1-z0,location=(0,0,(z0+z1)/2))
 o=bpy.context.object; o.name=name; return o

def boolean(a,b,op,delete=True):
 m=a.modifiers.new(op,'BOOLEAN'); m.operation=op; m.solver='MANIFOLD'; m.object=b; apply(a,m)
 if delete: bpy.data.objects.remove(b,do_unlink=True)
 return a

def check_closed(o,label):
 bm=bmesh.new(); bm.from_mesh(o.data); bad=sum(not e.is_manifold for e in bm.edges); bm.free()
 print('TOPOLOGY',label,o.name,bad,flush=True)
 if bad: raise RuntimeError(f'{label} {o.name}: {bad} non-manifold edges')

def fuse(name,parts):
 for ob in parts: check_closed(ob,'input')
 select(parts[0])
 for p in parts: p.select_set(True)
 bpy.ops.object.join(); o=bpy.context.object; o.name=name
 m=o.modifiers.new('Sculpt union','REMESH'); m.mode='VOXEL'; m.voxel_size=.14; m.use_smooth_shade=True; apply(o,m)
 m=o.modifiers.new('Soften joints','SMOOTH'); m.factor=.65; m.iterations=4; apply(o,m)
 m=o.modifiers.new('Compact printable mesh','DECIMATE'); m.ratio=.28; apply(o,m)
 check_closed(o,'fused')
 return o

def ear(side):
 # Broad rounded triangular ear, sunk well into the head.
 x=side*6.1
 v=[(x-side*3,-3,28),(x+side*3,-2.5,28),(x+side*1.6,-1,32.8),(x-side*3,1.3,28),(x+side*3,1.8,28),(x+side*1.6,1.4,32.8)]
 o=mesh('ear',v,[(0,1,2),(5,4,3),(0,3,4,1),(1,4,5,2),(2,5,3,0)])
 m=o.modifiers.new('Rounded ear edge','BEVEL'); m.width=.9; m.segments=4; apply(o,m)
 return o

def beak():
 # Closed tapered beak swept forward and down; broad root is buried in head.
 rings=[(-5.8,25.4,3.4,3.7),(-8,25.2,4,3.8),(-10.5,24.6,3.4,3.3),(-13,23.6,2.4,2.4),(-15,22.4,1.15,1.3),(-15.8,21.8,.3,.45)]
 v=[]; n=40
 for y,z,rx,rz in rings:
  for j in range(n):
   a=j*2*math.pi/n; v.append((rx*math.cos(a),y,z+rz*math.sin(a)))
 f=[tuple(reversed(range(n)))]
 for i in range(len(rings)-1):
  for j in range(n): f.append((i*n+j,i*n+(j+1)%n,(i+1)*n+(j+1)%n,(i+1)*n+j))
 f.append(tuple((len(rings)-1)*n+j for j in range(n)))
 return mesh('curved raven beak',v,f)

def animal(kind):
 parts=[cyl('base',10.2,0,1.7)]
 if kind=='cat':
  parts += [ell('body',(0,0,9.3),(7.5,5.8,8.6)),ell('head',(0,-.8,21.4),(9.7,7.6,8.5)),ear(-1),ear(1)]
  for side in (-1,1):
   parts += [ell('haunch',(side*4.8,1.4,5.4),(3.9,4.3,4.6)),ell('front leg',(side*2.9,-4.1,6.1),(2.1,2.1,5.1)),ell('paw',(side*2.9,-5.1,2.3),(2.5,3,1.7)),ell('muzzle',(side*1.3,-7.6,19.6),(2,1.3,1.5))]
  parts += [ell('tiny nose',(0,-8.5,20.4),(1.1,.7,.8)), tube('curled tail',[(4.5,1,2.3),(8.1,0,3),(10,0,6.5),(10,-.3,11),(8.5,-1,13),(7.4,-1,11.5)],2.1)]
 else:
  parts += [ell('body',(0,0,10.8),(9,7.5,10.2)),ell('head',(0,-.8,24),(8.9,7.9,8.6)),beak(),ell('tail',(0,6.3,5.7),(4.4,5.8,2.4),(.3,0,0))]
  for side in (-1,1):
   parts.append(ell('folded wing',(side*6.6,1.6,12),(3.3,5.6,6.8),(0,side*.2,side*.12)))
   for j in range(3):
    parts.append(ell('wing feather',(side*(7.1-j*.25),3+j*.9,9.5-j*1.3),(2.1,4.2,1.55),(.35,side*.25,0)))
   for j in range(3): parts.append(ell('toe',(side*3.1+(j-1)*1.25,-5.4,2.1),(.85,2,1.2)))
  parts += [ell('tuft',(0,-.4,32.3),(1.7,3.4,1.7),(.5,0,.15)),ell('tuft',(0,1.9,32),(1.5,3.2,1.4),(.25,0,-.15))]
 o=fuse(kind+'_pink',parts)
 # Flatten the base and scale both characters to the same overall height.
 bpy.ops.mesh.primitive_cube_add(size=200,location=(0,0,-100)); boolean(o,bpy.context.object,'DIFFERENCE')
 coords=[o.matrix_world@v.co for v in o.data.vertices]; top=max(v.z for v in coords); scale=ANIMAL_H/top
 # Bake world coordinates with floor contact; separate bodies touch shell floor, never overlap it.
 for v in o.data.vertices: v.co=(o.matrix_world@v.co)*scale+Vector((0,0,FLOOR))
 o.location=(0,0,0); o.rotation_euler=(0,0,0); o.scale=(1,1,1)
 # Blue eye inlays, pink pupil islands attached through inlay to the pink head.
 eyes=[]
 for side in (-1,1):
  if kind=='cat': c=Vector((side*3.65,-7.25,23)); s=(1.9,1.2,2.4)
  else: c=Vector((side*5.3,-6.6,27)); s=(1.95,1.4,2.45)
  c=c*scale+Vector((0,0,FLOOR)); s=tuple(x*scale for x in s)
  e=ell(kind+'_blue_eye',c,s)
  # Full blue eye inlay, with no fragile pupil islands or third material.
  boolean(o,e,'DIFFERENCE',delete=False)
  eyes.append(e)
 # Small shallow sculpted mouth under the cat muzzle.
 if kind=='cat':
  groove=tube('smile groove',[(-1.8,-8,18.7),(0,-8.3,18.2),(1.8,-8,18.7)],.24)
  for v in groove.data.vertices: v.co=v.co*scale+Vector((0,0,FLOOR))
  boolean(o,groove,'DIFFERENCE')
 # Join blue parts as one multi-body material mesh (two separate inserts is intentional).
 select(eyes[0]); eyes[1].select_set(True); bpy.ops.object.join(); eyes[0].name=kind+'_blue_eyes'
 for ob in (o,eyes[0]):
  check_closed(ob,'final')
  for p in ob.data.polygons: p.use_smooth=True
 return [o,eyes[0]]

def radius(z):
 # Truncated ovoid: 25.6 mm-wide flat bottom, broad belly, pointed crown.
 # At 55 mm the cap radius goes to zero; ring sampling closes the top explicitly.
 t=z/H
 return 23.2*math.sqrt(max(0,1-((z-23)/32)**2))*(1-.25*t)

def egg():
 # Revolved wall with 0.6 mm radial shell and a 0.6 mm sacrificial floor.
 n=128; steps=140
 # Closed meridian from underside centre to outside crown, then inner crown to floor centre.
 profile=[(0,0)]
 for i in range(steps):
  z=H*i/steps; profile.append((radius(z),z))
 profile.append((0,H)); profile.append((0,H-WALL))
 for i in reversed(range(steps)):
  z=FLOOR+(H-WALL-FLOOR)*i/steps
  profile.append((max(0,radius(z)-WALL),z))
 profile.append((0,FLOOR))
 v=[]; rings=[]
 for r,z in profile:
  if r==0: rings.append([len(v)]); v.append((0,0,z))
  else:
   ids=[]
   for j in range(n): ids.append(len(v)); a=j*2*math.pi/n; v.append((r*math.cos(a),r*math.sin(a),z))
   rings.append(ids)
 f=[]
 for a,b in zip(rings[:-1],rings[1:]):
  if len(a)==1 and len(b)==1: continue
  for j in range(n):
   k=(j+1)%n
   if len(a)==1: f.append((a[0],b[j],b[k]))
   elif len(b)==1: f.append((a[j],b[0],a[k]))
   else: f.append((a[j],b[j],b[k],a[k]))
 o=mesh('egg_blue',v,f)
 # Reorient inner cavity inward after mesh normal recalculation.
 outer_face_count=n*(steps+1)
 for poly in o.data.polygons:
  if poly.index>=outer_face_count: poly.flip()
 for p in o.data.polygons: p.use_smooth=True
 return o

parts=animal('raven')+animal('cat')+[egg()]
materials={}
for name,col in [('pink',PINK),('blue',BLUE)]:
 m=bpy.data.materials.new(name); m.diffuse_color=col; materials[name]=m
manifest={'units':'mm','egg_height_mm':H,'wall_radial_mm':WALL,'floor_mm':FLOOR,'animal_height_mm':ANIMAL_H,'review_only':True,'parts':[]}
for o in parts:
 # Weld numerical duplicate vertices and remove sub-micron degenerate edges before export.
 if not o.name.startswith('egg'):
  bm=bmesh.new(); bm.from_mesh(o.data)
  bmesh.ops.triangulate(bm,faces=list(bm.faces))
  bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=1e-5)
  bmesh.ops.dissolve_degenerate(bm,dist=1e-5,edges=list(bm.edges))
  
  unseen=set(bm.faces); debris=[]
  while unseen:
   seed=unseen.pop(); component={seed}; todo=[seed]
   while todo:
    face=todo.pop()
    for edge in face.edges:
     for neighbor in edge.link_faces:
      if neighbor in unseen: unseen.remove(neighbor); component.add(neighbor); todo.append(neighbor)
   vertices={v for face in component for v in face.verts}
   if len(component)==2 and len(vertices)==3:
    debris.extend(vertices)
  if debris:
   print('REMOVED_ZERO_VOLUME_DOUBLE_FACES',o.name,len(debris)//3,flush=True)
   bmesh.ops.delete(bm,geom=debris,context='VERTS')
  bm.to_mesh(o.data); bm.free(); o.data.update(); check_closed(o,'export')
 col='pink' if 'pink' in o.name else 'blue'; o.data.materials.clear(); o.data.materials.append(materials[col])
 # Exact same triangles in binary STL and browser data.
 o.data.calc_loop_triangles(); verts=[tuple(o.matrix_world@v.co) for v in o.data.vertices]; tris=[tuple(t.vertices) for t in o.data.loop_triangles]
 with (OUT/(o.name+'.stl')).open('wb') as f:
  f.write(b'Raven Cat original CAD v1; mm'.ljust(80,b'\0')); f.write(struct.pack('<I',len(tris)))
  for tri in tris:
   a,b,c=(Vector(verts[i]) for i in tri); no=(b-a).cross(c-a).normalized()
   f.write(struct.pack('<12fH',*no,*a,*b,*c,0))
 (OUT/(o.name+'.json')).write_text(json.dumps({'name':o.name,'positions':[round(x,5) for v in verts for x in v],'indices':[x for t in tris for x in t]},separators=(',',':')))
 bounds=[[min(v[k] for v in verts) for k in range(3)],[max(v[k] for v in verts) for k in range(3)]]
 manifest['parts'].append({'name':o.name,'color':col,'vertices':len(verts),'triangles':len(tris),'bounds_mm':bounds})
 print('EXPORTED',o.name,len(tris),bounds,flush=True)
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2))
# Arrange paired print layout for inspectable Blender source. Exported meshes retain local coordinates.
for o in parts:
 if o.name.startswith('raven'): o.location.x=-26
 if o.name.startswith('cat'): o.location.x=26
parts[-1].location.x=-26
copy=parts[-1].copy(); copy.data=parts[-1].data.copy(); copy.location.x=26; bpy.context.collection.objects.link(copy)
bpy.context.scene.unit_settings.system='METRIC'; bpy.context.scene.unit_settings.scale_length=.001
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'raven-cat-eggs.blend'))
print('CAD BUILD COMPLETE',flush=True)
