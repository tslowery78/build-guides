import runpy
for script in ('nest_preview.py','check.py','check_layers.py'):runpy.run_path(script,run_name='__main__')
