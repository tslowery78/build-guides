import runpy
for script in ('build.py','verify.py'):runpy.run_path(script,run_name='__main__')
