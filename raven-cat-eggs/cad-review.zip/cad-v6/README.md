# Raven and cat eggs v6 — internal shell-wall trees

Tom clarified that the supports should branch between the animal and the inside eggshell wall. v5's foot tabs were the wrong interpretation and are removed.

Each egg now contains two small blue trees, one on each rear side. Each starts at the inside shell wall near z=1.6 mm, forks near z=4.3 mm, and reaches two spots on the animal's rear flank at about z=13–15 mm. The four tips per animal are 0.48 mm in diameter, with 3.5 mm long narrow necks before the contact. The trunk/branch diameters are about 1.0–1.3 mm. Each contact is positioned using the first intersection of its incoming branch with the actual animal mesh, so thick stems stay clear. Everything stays below the irregular crack line (minimum about z=17.8 mm), so trees do not connect the lid to the lower nest.

The pink animals themselves are unchanged from v4, including the feet that start on the build plate. The tree roots bond to the interior shell wall and the narrow tips meet the animal's sides. These are explicitly modeled branching supports, not automatic slicer-generated trees. The physical strength of those joints is untested.

The thin v5 shell is retained: 0.6 mm main wall, 0.4 mm remaining at the irregular crack, 0.9 mm lower wall, 1.2 mm floor. The front has the small rounded crack-start slot. Both complete eggs still print in one uninterrupted two-color run, with blue left/Main and pink right/Auxiliary, no assembly or insertion pause.

The viewer's Trees button hides the animals and upper/front shell to expose the roots, forks and tips. Cutaway shows the trees with the animals present. Hatched is only an illustrative cut, not a fracture or release simulation.

Before another print: review the CAD, check the new branch toolpaths, and confirm the complete physical setup. Opening by hand and snapping the tree tips free must still be tested. The printed v4 needed a vise, so a pass on geometry or slicing does not establish easy opening. No v6 print has been sent.

## Verification and print hold

62 geometry checks and 23 browser checks passed. The standard slicer check has the known 229-switch warning, but the additional tree toolpath audit FAILED: sampled branch centerlines are not consistently covered by nominal extrusion beads, including several narrow-tip samples. Some trunk centers may be intentionally hollow; the tip discrepancies are unresolved. Do not send this slice. The 3 h 41 m 18 s / 43.50 g estimate describes this unchecked candidate only. Physical hand opening and release are also untested.
