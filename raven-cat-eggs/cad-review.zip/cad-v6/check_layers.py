"""Horizontal sections: detect new disconnected model islands at .16 mm slice phase."""
from pathlib import Path
import json,numpy as np,trimesh as tm
from shapely.ops import unary_union
P=Path(__file__).resolve().parent;result=[]
for kind in ('raven','cat'):
 # Printed colors are evaluated together for mechanical support.
 a=tm.load_mesh(P/(kind+'_pink.stl'));b=tm.load_mesh(P/(kind+'_blue_eyes.stl'))
 t=tm.load_mesh(P/(kind+'_blue_trees.stl'));shell=tm.load_mesh(P/'egg_blue.stl')
 animal=tm.boolean.union([a,b,t,shell],engine='manifold')
 heights=np.arange(.12,55,.16)
 sections=animal.section_multiplane([0,0,0],[0,0,1],heights)
 previous=None;islands=[];overhang=[]
 for z,sec in zip(heights,sections):
  if sec is None:continue
  polys=list(sec.polygons_full);current=unary_union(polys)
  if previous is not None:
   for p in polys:
    if p.area>.01 and p.intersection(previous.buffer(.04)).area<1e-5:islands.append(dict(z_mm=round(float(z),3),area_mm2=p.area,bounds=p.bounds))
   new=current.difference(previous.buffer(.20))
   if new.area>2:overhang.append(dict(z_mm=round(float(z),3),area_mm2=new.area))
  previous=current
 result.append(dict(kind=kind,floating_islands=islands,large_unsupported_increment=overhang))
 print(kind,'floating sections',islands,'large overhang layers',len(overhang),flush=True)
(P/'layer-checks.json').write_text(json.dumps(result,indent=2))
assert not any(r['floating_islands'] for r in result),'Floating model sections; do not print'
