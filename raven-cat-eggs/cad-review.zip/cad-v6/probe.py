import numpy as np,trimesh as tm
from pathlib import Path
P=Path(__file__).resolve().parent
s=(P/'build.py').read_text();exec(s[s.index('def flank('):s.index("for kind in ('raven','cat'):")])
for kind in ('raven','cat'):
 m=tm.load_mesh(P/'input'/(kind+'_pink.stl'))
 for z in (8,9,10,11,12,13,14,14.7):print(kind,z,[round(flank(m,y,z,1),3) for y in (-3.2,3.2)])
