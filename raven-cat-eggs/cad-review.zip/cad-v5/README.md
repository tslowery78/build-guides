# Raven and cat eggs v5 — easier-opening candidate

Tom reported on 2026-11-16 that v4 required a vise to open. That is a failed opening test, regardless of the passing geometry and slicer checks. Animal condition after opening has not yet been reported.

v5 keeps both animals inside their eggs in one uninterrupted two-color run. Blue left/Main, pink right/Auxiliary. Animal appearance above the feet is unchanged.

Changes from the printed v4:
- Shell normal thickness 1.4 → 0.6 mm, except the bottom wall is 0.9 mm through z=4 mm and transitions to 0.6 mm by z=6 mm. Floor stays 1.2 mm.
- Natural irregular groove remaining thickness 0.9 → 0.4 mm. A rounded 0.8 mm wide × 2.4 mm tall opening crosses its front as a crack starter.
- Three short blue floor links touch the pink foot. Each sacrificial neck is 0.48 mm wide × 0.64 mm tall. They start on the plate; no tall internal tree supports are added. Twist/release effort is untested.
- Removed the old internal locating ring; the retained foot shoulder still prevents the animal falling through the bottom opening.

The thin shell and necks deliberately depart from the two-line minimum for structural walls in the print recipe: their purpose is to break. This needs actual toolpath continuity checks. Do not infer printability merely from watertight meshes.

For the same local curvature/material, plate bending stiffness scales with thickness cubed: (0.6/1.4)^3 = 0.0787, about 8% of v4 away from the groove. This is a comparative stiffness estimate, not a prediction of opening force. PLA fracture, layer bonding, curvature and loading dominate the real opening test. Printed thickness may also differ from CAD when variable-width extrusion is used.

Before printing: inspect the revised CAD and slice the actual pair; confirm the thin wall, crack starter and all three links survive slicing. The first physical opening must work by hand; a vise is a failed test, not the intended way to open it. Inspect fracture edges and animal condition afterward. No new print is authorized by this design update alone.
