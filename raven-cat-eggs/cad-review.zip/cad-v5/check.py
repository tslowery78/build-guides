"""Geometry checks for intentional breakaway connections; run on CAD farm."""
from pathlib import Path
import json,math
import numpy as np,trimesh as tm,manifold3d as md
P=Path(__file__).resolve().parent;M=json.loads((P/'manifest.json').read_text());checks=[]
def check(n,c,**d):
 checks.append(dict(name=n,pass_=bool(c),**d));print(n,bool(c),d,flush=True)
def sol(m):return md.Manifold(md.Mesh(vert_properties=np.asarray(m.vertices,dtype=np.float32),tri_verts=np.asarray(m.faces,dtype=np.uint32)))
def load(n):return tm.load_mesh(P/(n+'.stl'),process=True)
parts={p['name']:load(p['name']) for p in M['parts']}
for n,m in parts.items():
 check(n+' closed volume',m.is_volume,volume_mm3=float(m.volume))
 j=json.loads((P/(n+'.json')).read_text());q=tm.Trimesh(np.array(j['positions']).reshape(-1,3),np.array(j['indices']).reshape(-1,3),process=True)
 check(n+' exact STL preview',np.array_equal(m.triangles,q.triangles))
S=sol(parts['egg_blue']);check('shell and links are one connected solid',len([x for x in S.decompose() if x.volume()>1e-6])==1)
# Only foot contacts are intentional; clip above the link tops for separation proof.
upper=md.Manifold.cube((100,100,80)).translate((-50,-50,.65))
nj=json.loads((P/'egg_nest_preview.json').read_text());N=sol(tm.Trimesh(np.array(nj['positions']).reshape(-1,3),np.array(nj['indices']).reshape(-1,3),process=True))
# Remove all tab ends back to the existing floor hole to model their breakage.
released_nest=N-md.Manifold.cylinder(1.3,7.6,7.6,128).translate((0,0,-.01))
pairs={'pink':[],'blue':[]}
for kind,x in [('raven',-26),('cat',26)]:
 pink=parts[kind+'_pink'];blue=parts[kind+'_blue_eyes'];A=sol(pink)+sol(blue)
 check(kind+' one bonded animal',len([q for q in A.decompose() if q.volume()>1e-6])==1)
 check(kind+' no color volume overlap',abs((A^S).volume())<1e-5,volume_mm3=(A^S).volume())
 joined=A+S
 check(kind+' deliberate bonded links',len([q for q in joined.decompose() if q.volume()>1e-6])==1)
 check(kind+' no shell contact above links',len([q for q in ((A^upper)+(S^upper)).decompose() if q.volume()>1e-6])==2)
 check(kind+' animal rests on bed',abs(pink.bounds[0,2])<1e-5)
 original=sol(tm.load_mesh(P/'input'/(kind+'_pink.stl'),process=True))
 missing=abs(((original^upper)-(sol(pink)^upper)).volume());added=abs(((sol(pink)^upper)-(original^upper)).volume())
 check(kind+' animal unchanged above link necks',max(missing,added)<1e-6,missing_mm3=missing,added_mm3=added)
 volumes=[(A.translate((0,0,float(z)))^released_nest).volume() for z in np.arange(0,24,.5)]
 check(kind+' clears lower nest after link removal',max(volumes)<1e-5,max_overlap_mm3=max(volumes))
 for m,c in [(pink,'pink'),(blue,'blue'),(parts['egg_blue'],'blue')]:
  q=m.copy();q.apply_translation((x,0,0));pairs[c].append(q)
for col,items in pairs.items():tm.util.concatenate(items).export(P/('pair_'+col+'.stl'))
# Numeric wall thickness evaluated from the CAD normal-offset construction.
check('thin shell .6 and crack .4 configured',M['shell_wall_normal_mm']==.6 and M['groove_remaining_normal_mm']==.4)
check('three intentionally sacrificial necks',M['foot_links']['count']==3 and M['foot_links']['height_mm']==.64)
check('both complete eggs one print',M['print_in_place'] and M['no_insertion_pause'])
report=dict(checks=checks,passed=all(c['pass_'] for c in checks),limitations=['Physical opening effort and neck breakage untested.','No prediction of fracture force; slicer must retain thin shell and links.'])
(P/'checks.json').write_text(json.dumps(report,indent=2));assert report['passed']
