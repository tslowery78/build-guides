"""v5 sacrificial shell and short foot links, mm; run on CAD farm.

Preserves v4 animals. Thin walls are intentional experimental breakaway features,
not structural walls. Slice continuity and physical opening must be checked.
"""
from pathlib import Path
import math,json
import numpy as np
import trimesh as tm
import manifold3d as md
P=Path(__file__).resolve().parent
M=json.loads((P/'input/manifest.json').read_text())
H=55.; FLOOR=1.2; WALL=.6; WEAK=.4; HOLE=7.6
N=240
knots=np.array(M['crack_knots_degrees_mm'])
def radius(z):return 1.06*23.2*math.sqrt(max(0,1-((z-23)/32)**2))*(1-.25*z/H)
def dr(z):
 t=max(1e-8,1-((z-23)/32)**2)
 return 1.06*23.2*(-(z-23)/(1024*math.sqrt(t))*(1-.25*z/H)-math.sqrt(t)*.25/H)
def raw(a):return float(np.interp(math.degrees(a)%360,knots[:,0],knots[:,1]))
def crack(a):
 d=math.pi/180
 return (raw(a-d)+2*raw(a)+raw(a+d))/4
def thick(z):return WALL+.3*max(0,min(1,(6-z)/2))
def inner(z):
 d=dr(z);n=math.hypot(1,d);t=thick(z)
 return radius(z)-t/n,z+t*d/n
def solid(m):return md.Manifold(md.Mesh(vert_properties=np.asarray(m.vertices,dtype=np.float32),tri_verts=np.asarray(m.faces,dtype=np.uint32)))
def mesh(s, simplify=False):
 a=(s.simplify(.0001) if simplify else s).to_mesh();m=tm.Trimesh(a.vert_properties[:,:3],a.tri_verts,process=True,validate=True)
 if not m.is_volume:
  counts=np.bincount(m.edges_unique_inverse);bad=m.edges_unique[counts!=2];print('BAD',len(bad),m.vertices[bad[:20]].tolist(),flush=True)
  raw=s.to_mesh();rm=tm.Trimesh(raw.vert_properties[:,:3],raw.tri_verts,process=True,validate=True);print('RAW',rm.is_volume,rm.is_watertight,flush=True)
 assert m.is_volume,(s.status(),m.is_watertight)
 return m
def cyl(r,z0,z1):return md.Manifold.cylinder(z1-z0,r,r,128).translate((0,0,z0))
def export(name,s,color,kind):
 m=mesh(s, name=='egg_blue');m.export(P/(name+'.stl'));m=tm.load_mesh(P/(name+'.stl'),process=True);assert m.is_volume
 (P/(name+'.json')).write_text(json.dumps(dict(name=name,positions=m.vertices.ravel().tolist(),indices=m.faces.ravel().tolist()),separators=(',',':')))
 M['parts'].append(dict(name=name,color=color,triangles=len(m.faces)))
 M['placements'].append(dict(name=name,kind=kind,assembly_z=0))
 print(name,len(m.faces),round(m.volume,3),flush=True)
 return m
zs=sorted(set([i*H/220 for i in range(221)]+[18.8,19.4,20,20.6,21.2,22.1,24.2,39]))
v=[];rings=[]
def ring(r,z):
 if abs(r)<1e-7:rings.append([len(v)]);v.append((0,0,z));return
 ids=[]
 for j in range(N):
  a=j*2*math.pi/N;ids.append(len(v));v.append((r*math.cos(a),r*math.sin(a),z))
 rings.append(ids)
ring(0,0)
for z in zs[:-1]:
 ids=[]
 for j in range(N):
  a=j*2*math.pi/N;w=max(0,min(1,(z-9)/9.8,(31-z)/9.8));zz=z+(crack(a)-20)*w
  d=dr(zz);n=math.hypot(1,d)
  groove=(WALL-WEAK)*max(0,1-abs(zz-crack(a))/.6)
  da=math.atan2(math.sin(a+math.pi/2),math.cos(a+math.pi/2))
  thumb=.14*max(0,1-(da/.24)**2)*max(0,1-((zz-crack(a)-2.1)/2.1)**2)
  cut=max(groove,thumb);r=radius(zz)-cut/n;zz+=cut*d/n
  ids.append(len(v));v.append((r*math.cos(a),r*math.sin(a),zz))
 rings.append(ids)
ring(0,H);ring(0,H-WALL)
pts=[inner(z) for z in zs[:-1]]
for i,(r,z) in enumerate(pts):
 if z>=FLOOR:
  ra,za=pts[i-1];pts=[(ra+(r-ra)*(FLOOR-za)/(z-za),FLOOR)]+pts[i:];break
for r,z in reversed(pts):ring(r,z)
ring(0,FLOOR)
faces=[]
for a,b in zip(rings[:-1],rings[1:]):
 if len(a)==len(b)==1:continue
 for j in range(N):
  k=(j+1)%N
  if len(a)==1:faces.append((a[0],b[j],b[k]))
  elif len(b)==1:faces.append((a[j],b[0],a[k]))
  else:faces.extend([(a[j],b[j],b[k]),(a[j],b[k],a[k])])
# Two closed boundary components: outer outward, cavity inward. Generic
# fix_normals would wrongly orient the cavity outward and fill the egg.
base=tm.Trimesh(v,np.asarray(faces)[:,::-1],process=True);assert base.is_volume
assert 3000 < base.volume < 15000, base.volume
shell=solid(base)-cyl(HOLE,-1,1.3)
# Small rounded vertical slit crosses the front groove. Its 0.8 mm width bridges
# locally at its rounded top; it does not create a detached upper shell.
cz=crack(-math.pi/2)
cap=md.Manifold.cylinder(6,.4,.4,48).rotate((90,0,0))
slot=md.Manifold.batch_hull([cap.translate((0,-19,cz-.8)),cap.translate((0,-19,cz+.8))])
print('VOLUMES base/shell/slot',base.volume,shell.volume(),slot.volume(), 'local volumes',[(solid(base)^md.Manifold.sphere(.1).translate(c)).volume() for c in [(0,0,20),(0,-19,20),(0,-22,20)]],flush=True)
shell=shell-slot
print('after slot',shell.volume(),flush=True)
# Three blue floor links end in 0.48 mm wide, 0.64 mm tall necks at the pink foot.
# They start on the bed; no tree canopy or trapped tall support needs removal.
links=None
for deg in (30,150,270):
 arm=md.Manifold.cube((1.4,.8,.64)).translate((7.3,-.4,0))
 neck=md.Manifold.cube((.7,.48,.64)).translate((6.8,-.24,0))
 link=(arm+neck).rotate((0,0,deg));links=link if links is None else links+link
shell=shell+links
M.update(version=5,shell_wall_normal_mm=WALL,groove_remaining_normal_mm=WEAK,
 lower_wall_normal_mm=.9,lower_wall_transition_z_mm=[4,6],groove_half_width_mm=.6,
 crack_start_slot_mm=[.8,2.4],foot_links=dict(count=3,width_mm=.48,height_mm=.64,colors='blue links touching pink foot'),
 parts=[],placements=[],review_only=True,physical_opening_test='v4 required a vise; v5 unprinted')
export('egg_blue',shell,'blue','shell')
for kind in ('raven','cat'):
 body=solid(tm.load_mesh(P/'input'/(kind+'_pink.stl'),process=True))-links
 export(kind+'_pink',body,'pink',kind)
 export(kind+'_blue_eyes',solid(tm.load_mesh(P/'input'/(kind+'_blue_eyes.stl'),process=True)),'blue',kind)
M['previews']={'hatched':'egg_nest_preview','meaning':'Illustrative cut at groove; tabs remain shown; physical fracture untested.'}
(P/'manifest.json').write_text(json.dumps(M,indent=2))
print('v5 build complete; experimental, not physically validated',flush=True)
